package qtec.china.customer.card;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import it.gmariotti.cardslib.library.prototypes.CardWithList;
import qtec.china.customer.R;
import qtec.china.customer.model.ModelPrice;

import java.util.ArrayList;
import java.util.List;

public class PriceTableCard extends CardWithList {
    private ModelPrice.Service mService;
    public PriceTableCard(Context context, ModelPrice.Service service) {
        super(context);
        mService = service;
    }

    @Override
    protected CardHeader initCardHeader() {
        CardHeader header = new CardHeader(getContext(), R.layout.card_header_inner_price) {
            @Override
            public void setupInnerViewElements(ViewGroup parent, View view) {
                super.setupInnerViewElements(parent, view);
                TextView title = (TextView) view.findViewById(R.id.card_header_inner_title);
                TextView subTitle = (TextView) view.findViewById(R.id.card_header_inner_subtitle);
                if( title != null ) title.setText(mService.title);
                if( subTitle != null ) subTitle.setText(mService.subtitle);
            }
        };
        // header.setTitle(mService.title);
        return header;
    }

    @Override
    protected void initCard() { }

    @Override
    protected List<ListObject> initChildren() {
        List<ListObject> mObjects = new ArrayList<>();
        for( ModelPrice.Table item : mService.getList() ) {
            mObjects.add(new TableObject(this, item));
        }
        return mObjects;
    }

    public class TableObject extends DefaultListObject {
        public ModelPrice.Table mTable;
        public TableObject(Card parentCard, ModelPrice.Table table) {
            super(parentCard);
            mTable = table;
        }
    }

    @Override
    public int getChildLayoutId() {
        return R.layout.card_main_inner_price;
    }

    @Override
    public View setupChildView(int i, ListObject listObject, View view, ViewGroup viewGroup) {
        TextView title = (TextView) view.findViewById(R.id.txt_title);
        TextView content = (TextView) view.findViewById(R.id.txt_content);
        if( listObject instanceof TableObject ) {
            ModelPrice.Table table = ((TableObject)listObject).mTable;
            if( title != null ) title.setText(table.title);
            if( content != null ) content.setText(table.content);
        }
        return view;
    }
}
