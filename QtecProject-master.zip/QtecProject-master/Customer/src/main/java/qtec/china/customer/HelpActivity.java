package qtec.china.customer;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.*;
import com.afollestad.materialdialogs.MaterialDialog;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.readystatesoftware.systembartint.SystemBarTintManager;
import qtec.china.customer.base.BaseActivity;


public class HelpActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        initStateBar();
        initToolbar();
    }

    private void initStateBar() {
        SystemBarTintManager sbt = new SystemBarTintManager(this);
        sbt.setStatusBarTintEnabled(true);
        sbt.setNavigationBarTintEnabled(true);
        sbt.setStatusBarAlpha(0.0f);
        sbt.setNavigationBarAlpha(1.0f);
        // sbt.setStatusBarTintResource(R.color.appThemeColorDark);
        sbt.setNavigationBarTintResource(R.color.appThemeColor);
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setBackgroundColor(Color.TRANSPARENT);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public void onClickHelp(View view) {
        new MaterialDialog.Builder(this)
                .title(R.string.title_activity_help)
                .content(R.string.title_activity_help)
                .positiveText(R.string.ok)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_help, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case R.id.action_help:
                SnackbarManager.show(
                        Snackbar.with(this)
                                .text(R.string.help)
                                .textColorResource(R.color.textColorPrimary)
                                .actionLabel(R.string.ok)
                                .actionColorResource(R.color.textColorPrimary)
                                .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                                .colorResource(R.color.appThemeColor)
                );
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
