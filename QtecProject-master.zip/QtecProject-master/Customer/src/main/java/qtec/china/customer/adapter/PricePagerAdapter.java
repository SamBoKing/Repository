package qtec.china.customer.adapter;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import qtec.china.customer.fragment.PriceFragment;
import qtec.china.customer.model.ModelPrice;

import java.util.ArrayList;
import java.util.List;

public class PricePagerAdapter extends FragmentStatePagerAdapter {
    List<PriceFragment> _list =  new ArrayList<>();
    public PricePagerAdapter(FragmentManager fm, List<ModelPrice.Service> items) {
        super(fm);
        for(ModelPrice.Service item : items) {
            _list.add(PriceFragment.newInstance(item));
        }
    }

    @Override
    public PriceFragment getItem(int i) {return _list.get(i); }

    @Override
    public int getCount() { return _list.size(); }

    @Override
    public CharSequence getPageTitle(int i) { return getItem(i).getTitle(); }
}
