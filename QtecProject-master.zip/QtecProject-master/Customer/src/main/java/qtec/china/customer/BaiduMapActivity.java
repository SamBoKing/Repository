package qtec.china.customer;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.*;
import android.widget.*;
import com.baidu.mapapi.search.sug.OnGetSuggestionResultListener;
import com.baidu.mapapi.search.sug.SuggestionResult;
import com.gc.materialdesign.views.ButtonFloat;
import com.gc.materialdesign.views.ProgressBarCircularIndeterminate;
import com.makeramen.roundedimageview.RoundedImageView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.orhanobut.logger.Logger;
import com.readystatesoftware.viewbadger.BadgeView;
import com.squareup.picasso.Picasso;
import qtec.china.customer.adapter.DrawerMenuAdapter;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.dialog.LoginDialog;
import qtec.china.customer.fragment.BaiduMapFragment;
import qtec.china.customer.model.ModelSearch;

import java.lang.reflect.Field;
import java.util.Calendar;

public class BaiduMapActivity extends BaseActivity implements View.OnClickListener {
    // Baidu Map
    private BaiduMapFragment mBaiduMap;

    // Search AotoComplet
    private SearchView mSearchView;
    private MenuItem mSearchItem;
    private MenuItem mCallItem;
    private SearchSuggestionsAdapter mSearchAdapter;
    private String mSearchText;
    private ProgressBarCircularIndeterminate mSearchProgress;
    private String[] from = new String[] { "title", "summary" };
    private int[] to = new int[] { R.id.tv_title, R.id.tv_summary };

    // Drawer Layout
    private View mDrawer;
    private View mProfileDescription;
    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private DrawerMenuAdapter mDrawerAdapter;
    private ActionBarDrawerToggle mDrawerToggle;

    // Toolbar
    private Toolbar mToolbar;
    private BadgeView mBadge;

    // User View
    private FrameLayout mMap;
    private RoundedImageView mUserImage;
    private TextView mUserName;
    private TextView mUserMileage;
    private ButtonFloat mBtnOrder;
    private Button mBtnMileage;
    private Button mBtnHelp;
    private Button mBtnSetting;
    private boolean isUserImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baidumap);
        initBaiduMap();
        initToolbar();
        initDrawer();
        initBadge();
        initView();
    }

    private void initBaiduMap() {
        mBaiduMap = BaiduMapFragment.newInstance(this);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.map, mBaiduMap, "map_fragment").commit();
    }

    private void initToolbar() {
        mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch(item.getItemId()) {
                    case R.id.action_call:
                        showCall();
                        break;
                }
                return false;
            }
        });

        // Custom Drawer Menu Icon Option
        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initDrawer() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawer = findViewById(R.id.left_drawer);
        mDrawerList = (ListView) findViewById(R.id.drawer_list);

        mDrawerAdapter = new DrawerMenuAdapter(this);
        mDrawerList.setAdapter(mDrawerAdapter);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar,
                R.string.drawer_open, R.string.drawer_close)
        {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
            }

            public void onDrawerClosed(View view) {
                mSearchItem.setVisible(true);
                mCallItem.setVisible(true);
            }

            public void onDrawerOpened(View drawerView) {
                onSearchViewClose();
                mSearchItem.setVisible(false);
                mCallItem.setVisible(false);
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void initBadge() {
        int badge_color = getResources().getColor(R.color.drawer_badge_color);
        Drawable badge_icon = Common.getDrawableWithColorFilter(this, R.drawable.ic_lens_orange600_24dp, badge_color);
        mBadge = new BadgeView(this, mToolbar);
        mBadge.setCompoundDrawablesWithIntrinsicBounds(badge_icon, null, null, null);
        mBadge.setBadgeBackgroundColor(Color.TRANSPARENT);
        mBadge.setBadgePosition(BadgeView.POSITION_TOP_LEFT);
        mBadge.setBadgeMargin(Common.getDimension(this, 26), Common.getDimension(this, 9));
    }

    private void initView() {
        mProfileDescription = findViewById(R.id.profile_description);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int back_img = R.drawable.description_night_small;
        if( 2 <= hour && hour <= 7 ) back_img = R.drawable.description_dawn_small;
        else if( 8 <= hour && hour <= 13 ) back_img = R.drawable.description_day_small;
        else if( 14 <= hour && hour <= 19 ) back_img = R.drawable.description_dusk_small;
        mProfileDescription.setBackgroundResource(back_img);

        mMap = (FrameLayout) findViewById(R.id.map);
        mSearchProgress = (ProgressBarCircularIndeterminate) findViewById(R.id.progress_search);
        mUserImage = (RoundedImageView) findViewById(R.id.user_img);
        mUserName = (TextView)findViewById(R.id.user_name);
        mUserMileage = (TextView)findViewById(R.id.user_mileage);
        mBtnMileage = (Button) findViewById(R.id.btn_charging);
        mBtnHelp = (Button) findViewById(R.id.btn_help);
        mBtnSetting = (Button) findViewById(R.id.btn_setting);
        mBtnOrder = (ButtonFloat) findViewById(R.id.btn_order);
        mBtnMileage.setOnClickListener(this);
        mBtnHelp.setOnClickListener(this);
        mBtnSetting.setOnClickListener(this);
        mBtnOrder.setOnClickListener(this);
        mUserImage.setOnClickListener(this);
    }

    private void toggleDrawer() {
        if ( mDrawerLayout.isDrawerOpen(mDrawer) ) {
            mDrawerLayout.closeDrawer(mDrawer);
        } else {
            mDrawerLayout.openDrawer(mDrawer);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUserData();
    }

    private void updateUserData() {
        if( mData.User.is_login ) {
            if( !isUserImage && !StringUtils.isEmpty(mData.User.img) ) {
                isUserImage = true;
                Picasso.with(this).load(mData.User.img).fit().into(mUserImage);
            }

            // User Data Replace
            if( !mData.User.is_update ) {
                mData.User.is_update = true;

                if( mData.User.is_menu ) {
                    mBadge.show();
                } else {
                    mBadge.hide();
                }
                mUserName.setText(mData.User.name);
                mUserMileage.setText(mData.User.mileage + "");
                mDrawerAdapter.updateMenuBadge(mData.User.is_order, mData.User.is_notice);
            }
        } else {
            mBadge.hide();
            mUserName.setText(R.string.please_login);
            mUserMileage.setText("");
            mDrawerAdapter.updateMenuBadge(false, false);
        }
    }

    @Override
    public void onClick(View view) {
        switch( view.getId() ) {
            case R.id.user_img:
                mDrawerLayout.closeDrawer(mDrawer);
                loginWithStartActivity(UserActivity.class);
                break;
            case R.id.btn_charging:
                mDrawerLayout.closeDrawer(mDrawer);
                loginWithStartActivity(ChargingActivity.class);
                break;
            case R.id.btn_order:
                loginWithStartActivity(OrderActivity.class);
                break;
            case R.id.btn_help:
                mDrawerLayout.closeDrawer(mDrawer);
                startActivity(new Intent(this, HelpActivity.class));
                break;
            case R.id.btn_setting:
                mDrawerLayout.closeDrawer(mDrawer);
                startActivity(new Intent(this, SettingsActivity.class));
                break;
        }
    }

    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            mDrawerLayout.closeDrawer(mDrawer);
            switch( position ) {
                case 0:
                    loginWithStartActivity(HistoryActivity.class);
                    break;
                case 1:
                    loginWithStartActivity(MileageActivity.class);
                    break;
                case 2:
                    startActivity(new Intent(BaiduMapActivity.this, ServiceActivity.class));
                    break;
                case 3:
                    startActivity(new Intent(BaiduMapActivity.this, PriceActivity.class));
                    break;
                case 4:
                    startActivity(new Intent(BaiduMapActivity.this, RecommendActivity.class));
                    break;
                case 5:
                    loginWithStartActivity(NoticeActivity.class);
                    break;
                case 6:
                    startActivity(new Intent(BaiduMapActivity.this, EtceteraActivity.class));
                    break;
            }
        }
    }

    public void loginWithStartActivity(final Class<?> cls) {
        if( mData.User.is_login ) {
            startActivity(new Intent(this, cls));
        } else {
            LoginDialog login = new LoginDialog();
            login.setOnLoginListener(new LoginDialog.LoginListener() {
                @Override
                public void onLoginSuccess() {
                    updateUserData();
                    startActivity(new Intent(BaiduMapActivity.this, cls));
                }
            });
            login.show(getSupportFragmentManager(), "login");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_map, menu);

        mCallItem = menu.findItem(R.id.action_call);
        mSearchItem = menu.findItem(R.id.action_search);

        // Searchable Custom Setting
        setupSearchView();
        return true;
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed() {
        if ( mDrawerLayout.isDrawerOpen(mDrawer) ) {
            mDrawerLayout.closeDrawer(mDrawer);
        } else {
            showExit();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            toggleDrawer();
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    private void setupSearchView() {
        mSearchView = (SearchView) MenuItemCompat.getActionView(mSearchItem);
        if( mSearchView == null ) {
            Logger.e("Not Found SearchView");
            return;
        }

        // Searchable Xml Setting
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        mSearchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        // SearchView Cursor Color Change
        SearchView.SearchAutoComplete searchText = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        setCursorColor(searchText, getResources().getColor(R.color.textColorPrimary));

        mSearchView.setQueryHint(getString(R.string.search_view_hint));
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                if( s.equalsIgnoreCase(mSearchText) ) {
                    drawModelSearch();
                } else {
                    mSearchText = s;
                    requestSearch(mSearchText);
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                mSearchAdapter.changeCursor(null);
                return false;
            }
        });

        mSearchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    onSearchViewClose();
                }
            }
        });

        mSearchAdapter = new SearchSuggestionsAdapter(this);
        mSearchView.setSuggestionsAdapter(mSearchAdapter);
        mSearchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
            @Override
            public boolean onSuggestionSelect(int index) {
                return false;
            }

            @Override
            public boolean onSuggestionClick(int index) {
                Cursor cursor = (Cursor)mSearchAdapter.getItem(index);
                ModelSearch.Search item = mData.Search.convert(cursor);
                SnackbarManager.show(
                        Snackbar.with(BaiduMapActivity.this)
                                .textColorResource(R.color.textColorPrimary)
                                .colorResource(R.color.appThemeColor)
                                .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                                .text("Item Click : " + item.title)
                );

                mBaiduMap.updateRider();
                return false;
            }
        });
    }

    public class SearchSuggestionsAdapter extends SimpleCursorAdapter {
        int mFilterTextColor;
        public SearchSuggestionsAdapter(Context context) {
            super(context, R.layout.list_item_search, null, from, to, 0);
            mFilterTextColor = getResources().getColor(R.color.search_item_filter);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            super.bindView(view, context, cursor);
            TextView tv1 = (TextView) view.findViewById(R.id.tv_title);
            TextView tv2 = (TextView) view.findViewById(R.id.tv_summary);
            Common.setTextViewColorPartial(tv1, mSearchText, mFilterTextColor);
            Common.setTextViewColorPartial(tv2, mSearchText, mFilterTextColor);
        }
    }

    public void onSearchViewClose() {
        hideKeyboard();
        if (mSearchItem != null) {
            mSearchItem.collapseActionView();
        }

        if( mSearchView != null ) {
            mSearchView.setQuery("", false);
        }
    }

    private void requestSearch(String search) {
        mSearchProgress.setVisibility(View.VISIBLE);

        mBaiduMap.requestSearch(new OnGetSuggestionResultListener() {
            @Override
            public void onGetSuggestionResult(SuggestionResult suggestionResult) {
                mSearchProgress.setVisibility(View.GONE);
                mData.Search.updateList(suggestionResult.getAllSuggestions());
                drawModelSearch();
            }
        }, search);

//        mBaiduMap.requestSearch(new OnGetGeoCoderResultListener() {
//            @Override
//            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {
//            }
//
//            @Override
//            public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {
//                mSearchProgress.setVisibility(View.GONE);
//                mData.Search.updateList();
//                drawModelSearch();
//            }
//        }, search);

//        volleyer().get(UrlHelper.makeUrl(Page.getSearch))
//                .addHeader("search", search)
//                .withErrorListener(this)
//                .withListener(new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        mSearchProgress.setVisibility(View.GONE);
//                        mData.Search = new Gson().fromJson(response, ModelSearch.class);
//
//                        // TODO : Test Logic
//                        if (mSearchText.equals("bbb")) {
//                            mData.Search.clearList();
//                        } else {
//                            mData.Search.updateList(mSearchText);
//                        }
//
//                        drawModelSearch();
//                    }
//                })
//                .execute();
    }

    private void drawModelSearch() {
        mSearchView.setQuery(mSearchText, false);

        Cursor cursor = mData.Search.getCursor();
        mSearchAdapter.changeCursor(cursor);
        if ( cursor == null || cursor.getCount() == 0) {
            SnackbarManager.show(
                    Snackbar.with(BaiduMapActivity.this)
                            .position(Snackbar.SnackbarPosition.TOP)
                            .margin(Common.getDimension(this, 15), Common.getDimension(this, 15))
                            .textColorResource(R.color.textColorPrimary)
                            .colorResource(R.color.appThemeColor)
                            .textTypeface(Typeface.DEFAULT_BOLD)
                            .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                            .text( (cursor == null) ? R.string.please_wait : R.string.not_found_search ), mMap);

        } else {
            hideKeyboard();
        }
    }

    public void setCursorColor(SearchView.SearchAutoComplete view, int color) {
        if (view != null) {
            try {
                final Field fCursorDrawableRes = TextView.class.getDeclaredField("mCursorDrawableRes");
                fCursorDrawableRes.setAccessible(true);
                final int mCursorDrawableRes = fCursorDrawableRes.getInt(view);
                final Field fEditor = TextView.class.getDeclaredField("mEditor");
                fEditor.setAccessible(true);
                final Object editor = fEditor.get(view);
                final Class<?> clazz = editor.getClass();
                final Field fCursorDrawable = clazz.getDeclaredField("mCursorDrawable");
                fCursorDrawable.setAccessible(true);
                final Drawable[] drawables = new Drawable[2];
                drawables[0] = view.getContext().getResources().getDrawable(mCursorDrawableRes);
                drawables[1] = view.getContext().getResources().getDrawable(mCursorDrawableRes);
                drawables[0].setColorFilter(color, PorterDuff.Mode.SRC_IN);
                drawables[1].setColorFilter(color, PorterDuff.Mode.SRC_IN);
                fCursorDrawable.set(editor, drawables);
            } catch (final Throwable ignored) {
            }
        }
    }
}