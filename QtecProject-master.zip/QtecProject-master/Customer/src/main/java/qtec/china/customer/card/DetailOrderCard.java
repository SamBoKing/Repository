package qtec.china.customer.card;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import it.gmariotti.cardslib.library.prototypes.CardWithList;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.model.ModelDetail;

import java.util.ArrayList;
import java.util.List;

public class DetailOrderCard extends CardWithList {
    private BaseActivity mActivity;
    private ModelDetail mDetail;
    public DetailOrderCard(BaseActivity activity, ModelDetail detail) {
        super(activity);
        mActivity = activity;
        mDetail = detail;
    }

    @Override
    protected CardHeader initCardHeader() {
        CardHeader header = new CardHeader(getContext(), R.layout.card_header_inner_detail_order) {
            @Override
            public void setupInnerViewElements(ViewGroup parent, View view) {
                super.setupInnerViewElements(parent, view);
            }
        };
        return header;
    }

    @Override
    protected void initCard() { }

    @Override
    protected List<ListObject> initChildren() {
        List<ListObject> mObjects = new ArrayList<>();
        for( ModelDetail.Order item : mDetail.getList() ) {
            mObjects.add(new TableObject(this, item));
        }
        return mObjects;
    }

    public class TableObject extends DefaultListObject {
        public ModelDetail.Order mOrder;
        public TableObject(Card parentCard, ModelDetail.Order order) {
            super(parentCard);
            mOrder = order;
        }
    }

    @Override
    public int getChildLayoutId() {
        return R.layout.card_main_inner_detail_order;
    }

    @Override
    public View setupChildView(int i, ListObject listObject, View view, ViewGroup viewGroup) {
        TextView date = (TextView) view.findViewById(R.id.txt_date);
        TextView title = (TextView) view.findViewById(R.id.txt_title);
        if( listObject instanceof TableObject ) {
            ModelDetail.Order order = ((TableObject)listObject).mOrder;
            if( date != null ) date.setText(order.date);
            if( title != null ) title.setText(order.title);
        }
        return view;
    }
}
