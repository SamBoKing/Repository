package qtec.china.customer.card;

import android.content.Context;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.afollestad.materialdialogs.MaterialDialog;
import com.squareup.picasso.Picasso;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import it.gmariotti.cardslib.library.internal.CardThumbnail;
import it.gmariotti.cardslib.library.internal.base.BaseCard;
import qtec.china.customer.R;
import qtec.china.customer.model.ModelService;

public class ServiceCard extends Card {
    private ModelService.Service mItem;
    public ServiceCard(Context context, ModelService.Service item) {
        super(context, R.layout.card_inner_service);
        this.mItem = item;
    }

    public void init() {
        CardHeader header = new CardHeader(getContext(),R.layout.card_header_inner_service);
        header.setButtonOverflowVisible(true);
        header.setTitle(mItem.title);
        header.setPopupMenu(R.menu.popup_service, new CardHeader.OnClickCardHeaderPopupMenuListener() {
            @Override
            public void onMenuItemClick(BaseCard card, MenuItem item) {
                showDetail();
            }
        });
        addCardHeader(header);

        ServiceGridThumb thumbnail = new ServiceGridThumb(getContext());
        thumbnail.setExternalUsage(true);
        // thumbnail.setUrlResource(mItem.img);
        // thumbnail.setErrorResource(R.drawable.ic_service_default);
        addCardThumbnail(thumbnail);

        setOnClickListener(new OnCardClickListener() {
            @Override
            public void onClick(Card card, View view) {
                showDetail();
            }
        });
    }

    @Override
    public void setupInnerViewElements(ViewGroup parent, View view) {
        TextView tel = (TextView) view.findViewById(R.id.txt_tel);
        tel.setText(mItem.tel);
    }

    private void showDetail() {
        new MaterialDialog.Builder(getContext())
                .title(mItem.title)
                .content(mItem.detail)
                .positiveText(R.string.ok)
                .show();
    }

    class ServiceGridThumb extends CardThumbnail {
        public ServiceGridThumb(Context context) {
            super(context);
        }

        @Override
        public void setupInnerViewElements(ViewGroup parent, View viewImage) {
            ((ImageView) viewImage).setImageResource(R.drawable.ic_service_default);

            // setExternalUsage == true
            Picasso.with(getContext()).setIndicatorsEnabled(true);  //only for debug tests
            Picasso.with(getContext())
                    .load(mItem.img)
                    .error(R.drawable.ic_service_default)
                    // .fit()
                    .into((ImageView) viewImage);
        }
    }
}
