package qtec.china.customer.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseFragment;

public class AgreementFragment extends BaseFragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_agreement, container, false);
        getActivity().setTitle(R.string.title_fragment_agreement);
        return rootView;
    }
}
