package qtec.china.customer.helper;

public class UrlHelper {
    // Release
    // static String SERVER_URL = "http://";
    // static String SERVER_PAGE_EXT = "aspx";

    // Debug
    static String SERVER_URL = "https://raw.githubusercontent.com/SamBoKing/QtecWebSite/master";
    static String SERVER_PAGE_EXT = "json";

    public enum Page {
        getRider,
        getConfig,
        getUser,
        getReUser,
        getSearch,
        getCret,
        getLogin,
        getNotice,
        getResult,
        getPrice,
        getService,
        getMileage,
        getHistory,
        getCharging,
        getOrder,
        getDetail1,
        getDetail2,
        getDetail3,
        getCancel,
        getRating
    }

    public static String makeUrl(Page page) {
        return String.format("%s/%s.%s", SERVER_URL, page.name(), SERVER_PAGE_EXT);
    }

}
