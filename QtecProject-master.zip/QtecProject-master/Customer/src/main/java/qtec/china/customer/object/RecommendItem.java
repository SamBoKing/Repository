package qtec.china.customer.object;

public class RecommendItem {
    public String title;
    public int qrcode;
    public int key;
    public String link;
    public RecommendItem(String title, int qrcode, int key, String link) {
        this.title = title;
        this.qrcode = qrcode;
        this.key = key;
        this.link = link;
    }
}
