package qtec.china.customer;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.ShareActionProvider;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import qtec.china.customer.adapter.RecommendPagerAdapter;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.custom.SlidingTabLayout;
import qtec.china.customer.object.RecommendItem;


public class RecommendActivity extends BaseActivity {
    private ShareActionProvider mShareActionProvider;
    private Intent mShareIntent;
    private SlidingTabLayout mSlidingTabLayout;
    private RecommendPagerAdapter mAdapter;
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend);
        initToolbar();
        initPager();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initPager() {
        mAdapter = new RecommendPagerAdapter(this, getSupportFragmentManager(), new RecommendItem[] {
                new RecommendItem(
                        getString(R.string.recommend_tab_title1),
                        R.drawable.qr_img1,
                        R.string.key_qr_code1,
                        getString(R.string.recommend_link_text1)),

                new RecommendItem(
                        getString(R.string.recommend_tab_title2),
                        R.drawable.qr_img2,
                        R.string.key_qr_code2,
                        getString(R.string.recommend_link_text2))
        });

        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mAdapter);

        mSlidingTabLayout = (SlidingTabLayout) findViewById(R.id.sliding_tabs);
        ColorStateList colors = Common.getStatListColorWithAlpha(getResources().getColor(R.color.appThemeToolbarTextColor), 0.5f);
        mSlidingTabLayout.setTextColor(colors);
        mSlidingTabLayout.setBackgroundColor(getResources().getColor(R.color.appThemeColor));
        mSlidingTabLayout.setSelectedIndicatorColors(getResources().getColor(R.color.appThemeToolbarTextColor));
        mSlidingTabLayout.setDistributeEvenly(true);
        mSlidingTabLayout.setViewPager(mViewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_recommend, menu);

        // Fetch and store ShareActionProvider
        MenuItem shareItem = menu.findItem(R.id.action_share);
        mShareActionProvider = (ShareActionProvider)MenuItemCompat.getActionProvider(shareItem);
        if( mShareIntent != null ) {
            mShareActionProvider.setShareIntent(mShareIntent);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setShearIntent(Intent intent) {
        if (mShareActionProvider != null) {
            mShareActionProvider.setShareIntent(intent);
        } else {
            mShareIntent = intent;
            /* Test
            try {
                Uri uri = Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(),
                        BitmapFactory.decodeResource(getResources(), R.drawable.ic_lens_orange600_24dp), null, null));

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_SUBJECT, "SUBJECT");
                intent.putExtra(Intent.EXTRA_TEXT, "TEXT");
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                mShareActionProvider.setShareIntent(intent);
                // startActivity(Intent.createChooser(intent, "Share"));
            } catch (NullPointerException e) { }
            */
        }
    }
}
