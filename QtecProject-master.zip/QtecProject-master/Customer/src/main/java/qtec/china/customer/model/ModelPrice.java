package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelPrice {
    public boolean is_load;

    public class Table {
        public String title;
        public String content;
    }

    public class Service {
        public String title;
        public String subtitle;
        List<Table> list = new ArrayList<>();
        public List<Table> getList() {
            return list;
        }
    }

    public class Area {
        public String title;
        List<Service> list = new ArrayList<>();
        public List<Service> getList() {
            return list;
        }
    }

    List<Area> list = new ArrayList<>();
    public List<Area> getList() {
        return list;
    }

    public Area getItem(int index) {
        if( list.size() > index ) {
            return list.get(index);
        }
        return null;
    }
}
