package qtec.china.customer.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.readystatesoftware.viewbadger.BadgeView;
import qtec.china.customer.R;
import qtec.china.customer.common.Common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DrawerMenuAdapter extends BaseAdapter {
    class MenuItem {
        int text;
        int icon;
        boolean badge;
        public MenuItem(int text, int icon, boolean badge) {
            this.text = text;
            this.icon = icon;
            this.badge = badge;
        }
    }
    private List<MenuItem> mList = new ArrayList<>();
    private LayoutInflater mInflater;
    private Context mContext;

    private MenuItem mMenuOrder;
    private MenuItem mMenuNotice;
    public DrawerMenuAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        mContext = context;
        initItem();
    }

    private void initItem() {
        mMenuOrder = new MenuItem(R.string.drawer_menu1, R.drawable.ic_format_list_bulleted_white_24dp, false);
        mList.add(mMenuOrder);
        mList.add(new MenuItem(R.string.drawer_menu2, R.drawable.ic_favorite_outline_white_24dp, false));
        mList.add(new MenuItem(R.string.drawer_menu3, R.drawable.ic_apps_white_24dp, false));
        mList.add(new MenuItem(R.string.drawer_menu4, R.drawable.ic_attach_money_white_24dp, false));
        mList.add(new MenuItem(R.string.drawer_menu5, R.drawable.ic_thumb_up_white_24dp, false));
        mMenuNotice = new MenuItem(R.string.drawer_menu6, R.drawable.ic_content_paste_white_24dp, false);
        mList.add(mMenuNotice);
        mList.add(new MenuItem(R.string.drawer_menu7, R.drawable.ic_more_horiz_white_24dp, false));
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public MenuItem getItem(int i) {
        return mList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if( convertView == null ) {
            convertView = mInflater.inflate(R.layout.list_item_drawer, null);
            holder = new ViewHolder();
            holder.text = (TextView) convertView.findViewById(R.id.text);
            holder.badge = getBadgeView(holder.text);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        MenuItem item = getItem(position);
        holder.text.setText( item.text );
        holder.text.setCompoundDrawablesWithIntrinsicBounds(getIconDrawable(item.icon), null, null, null);
        holder.text.setCompoundDrawablePadding(Common.getDimension(mContext, 34));

        if ( item.badge ) {
            holder.badge.show();
        } else {
            holder.badge.hide();
        }
        return convertView;
    }

    private BadgeView getBadgeView(View target) {
        int badge_color = mContext.getResources().getColor(R.color.drawer_badge_color);
        Drawable badge_icon = Common.getDrawableWithColorFilter(mContext, R.drawable.ic_lens_orange600_24dp, badge_color);
        BadgeView badge = new BadgeView(mContext, target);
        badge.setBadgeBackgroundColor(Color.TRANSPARENT);
        badge.setCompoundDrawablesWithIntrinsicBounds(badge_icon, null, null, null);
        return badge;
    }

    private Drawable getIconDrawable(int icon) {
        return Common.getDrawableWithColorFilter(mContext, icon, mContext.getResources().getColor(R.color.appThemeColor));
    }

    public void updateMenuBadge(boolean is_order, boolean is_notice) {
        mMenuOrder.badge = is_order;
        mMenuNotice.badge = is_notice;
        notifyDataSetChanged();
    }

    static class ViewHolder {
        TextView text;
        BadgeView badge;
    }
}
