package qtec.china.customer.fragment;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMapOptions;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.model.LatLng;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import qtec.china.customer.R;
import qtec.china.customer.baidumap.RiderClusterRenderer;
import qtec.china.customer.baidumap.library.clustering.Cluster;
import qtec.china.customer.baidumap.library.clustering.ClusterItem;
import qtec.china.customer.baidumap.library.clustering.ClusterManager;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.base.BaseBaiduMapFragment;
import qtec.china.customer.model.ModelDetail;
import qtec.china.customer.model.ModelRider;

import java.util.ArrayList;
import java.util.List;

public class DetailMapFragment extends BaseBaiduMapFragment implements ClusterManager.OnClusterItemClickListener {

    final int IMAGE_CHECK_TIME = 1000;
    final int IMAGE_CHECK_COUNT = 3;

    private int mImageCheckCount;
    private BaseActivity mActivity;
    private BaiduMap mBaiduMap;
    private ClusterManager<ModelRider.Rider> mClusterManager;
    private List<Target> mTargetList = new ArrayList<>();
    private ModelRider.Rider mRider;

    public static DetailMapFragment newInstance(BaseActivity activity) {
        MapStatus ms = new MapStatus.Builder().zoom(15).build();
        BaiduMapOptions bo = new BaiduMapOptions().mapStatus(ms)
                .compassEnabled(false).zoomControlsEnabled(false);
        return newInstance(activity, bo);
    }

    public static DetailMapFragment newInstance(BaseActivity activity, BaiduMapOptions baiduMapOptions) {
        DetailMapFragment map = new DetailMapFragment();
        map.setArguments(activity, baiduMapOptions);
        return map;
    }

    public DetailMapFragment() {
    }

    private void setArguments(BaseActivity activity, BaiduMapOptions baiduMapOptions) {
        mActivity = activity;
        setMapOptions(baiduMapOptions);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        initBaiduMap();
    }

    private void initBaiduMap() {
        mBaiduMap = getBaiduMap();
        mBaiduMap.setMyLocationEnabled(true);
        mBaiduMap.getUiSettings().setZoomGesturesEnabled(true);
        mBaiduMap.setOnMapLoadedCallback(new BaiduMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                onMapReady();
            }
        });

        mClusterManager = new ClusterManager<>(mActivity, mBaiduMap);
        mClusterManager.setRenderer(new RiderClusterRenderer(mActivity, mBaiduMap, mClusterManager));
        mClusterManager.setOnClusterItemClickListener(this);
        mBaiduMap.setOnMapStatusChangeListener(mClusterManager);
        mBaiduMap.setOnMarkerClickListener(mClusterManager);
    }

    private void onMapReady() {
        ModelDetail detail = mActivity.mData.Detail;
        LatLng latlng = new LatLng(detail.lat, detail.lng);

        mRider = new ModelRider.Rider();
        mRider.name = detail.name;
        mRider.url = detail.url;
        mRider.rating = detail.rating;
        mRider.lat = latlng.latitude;
        mRider.lng = latlng.longitude;
        loadImage();
        checkImage();
    }

    private void loadImage() {
        int w = (int)getResources().getDimension(R.dimen.marker_width);
        int h = (int)getResources().getDimension(R.dimen.marker_height);

        Target target = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                mRider.bitmap = bitmap;
                mTargetList.remove(this);
            }
            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                mTargetList.remove(this);
            }
            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) { }
        };
        // 강한 참조를 만들기 위한 로직
        mTargetList.add(target);

        Picasso.with(mActivity).load(mRider.url).resize(w, h).into(target);
    }

    private void checkImage() {
        if( mRider.bitmap != null || mImageCheckCount++ > IMAGE_CHECK_COUNT ) {
            mImageCheckCount = 0;
            drawModelRider();
        } else {
            new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    checkImage();
                    super.handleMessage(msg);
                }
            }.sendEmptyMessageDelayed(0, IMAGE_CHECK_TIME);
        }
    }

    private void drawModelRider() {
        LatLng latlng = new LatLng(mRider.lat, mRider.lng);
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLngZoom(latlng,
                getResources().getInteger(R.integer.map_defuault_zoom)));

        mClusterManager.clearItems();
        mClusterManager.addItem(mRider);
        mClusterManager.cluster();
    }

    public void moveMap() {
        LatLng latlng = new LatLng(mRider.lat, mRider.lng);
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLng(latlng));
    }

    @Override
    public boolean onClusterItemClick(ClusterItem item) {
        moveMap();
        return false;
    }
}
