package qtec.china.customer.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.view.CardViewNative;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseFragment;
import qtec.china.customer.card.PriceTableCard;
import qtec.china.customer.model.ModelPrice;

public class PriceFragment extends BaseFragment {
    private View mRootView;
    private ModelPrice.Service mItem;
    public static PriceFragment newInstance(ModelPrice.Service item) {
        PriceFragment fr = new PriceFragment();
        fr.setArguments(item);
        return fr;
    }

    private void setArguments(ModelPrice.Service item) {
        this.mItem = item;
    }

    public String getTitle() {
        return StringUtils.isEmpty(mItem.title) ? "Empty" :  mItem.title;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_price, container, false);
        return mRootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initCard();
    }

    private void initCard() {
        PriceTableCard card = new PriceTableCard(mActivity, mItem);
        card.init();

        CardViewNative cardView = (CardViewNative) mRootView.findViewById(R.id.card_price_table);
        cardView.setCard(card);
    }
}
