package qtec.china.customer.manager;

import android.content.Context;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;
import org.apache.http.HttpResponse;

import java.io.IOException;
import java.util.Map;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;

public class VolleyManager {
    static {
        VolleyLog.DEBUG = true;
    }

    private static final int DEFAULT_TIMEOUT_MS = 2500;     /** The default socket timeout in milliseconds */
    private static final int DEFAULT_MAX_RETRIES = 5;       /** The default number of retries */
    private static final float DEFAULT_BACKOFF_MULT = 1f;   /** The default backoff multiplier */

    public static void init(Context context) {
        volleyer( Volley.newRequestQueue(context, new CustomHurlStack()) )
                .settings()
                .setAsDefault()
                .done();
    }

    static class CustomHurlStack extends HurlStack {
        DefaultRetryPolicy mRetryPolicy;
        private void setRetryPolicy(Request<?> request) {
            try {
                if ( mRetryPolicy == null || !request.getRetryPolicy().equals(mRetryPolicy) ) {
                    mRetryPolicy = new DefaultRetryPolicy(DEFAULT_TIMEOUT_MS, DEFAULT_MAX_RETRIES, DEFAULT_BACKOFF_MULT);
                }
                request.setRetryPolicy(mRetryPolicy);
            } catch (Exception ex) {
                VolleyLog.e("Exception setRetryPolicy - Error : %s", ex.getMessage());
            }
        }

        @Override
        public HttpResponse performRequest(Request<?> request, Map<String, String> additionalHeaders) throws IOException, AuthFailureError {
            setRetryPolicy(request);
            return super.performRequest(request, additionalHeaders);
        }
    }
}
