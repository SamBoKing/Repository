package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelDetail {
    public String id;
    public String rid;
    public String name;
    public String url;
    public String call;
    public double lat;
    public double lng;
    public int rating;
    public boolean is_rating;
    public String data1;
    public String data2;
    public String data3;
    public String data4;
    public String data5;
    public String data6;
    public String data7;
    public String data8;

    public class Order {
        public String date;
        public String title;
    }
    List<Order> list = new ArrayList<>();
    public List<Order> getList() {
        return list;
    }
}
