package qtec.china.customer;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.view.CardViewNative;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.card.DetailOrderCard;
import qtec.china.customer.card.DetailRiderCard;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.model.ModelCancel;
import qtec.china.customer.model.ModelConfig;
import qtec.china.customer.model.ModelDetail;

import java.util.List;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;
import static qtec.china.customer.helper.UrlHelper.Page;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class DetailActivity extends BaseActivity {
    private CardViewNative mCardRider;
    private CardViewNative mCardOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        initToolbar();
        initView();

        String id = "";
        Intent i =  getIntent();
        if( i != null ) {
            id = i.getStringExtra("id");
            // Todo Test
            if( id == null ) {
                id = "1";
            }
        }
        if( !StringUtils.isEmpty(id) ) {
            // Todo Test
            // requestModelConfig();
            requestModelDetail(id);
        } else {
            showError();
        }
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    private void initView() {
        mCardRider = (CardViewNative) findViewById(R.id.card_detail_rider);
        mCardOrder = (CardViewNative) findViewById(R.id.card_detail_order);
        mCardRider.setVisibility(View.GONE);
        mCardOrder.setVisibility(View.GONE);
    }

    private void drawModelDetail() {
        drawCardRider();
        drawCardOrder();
    }

    private void drawCardRider() {
        DetailRiderCard card = new DetailRiderCard(this, mData.Detail);
        mCardRider.setCard(card);
        mCardRider.setVisibility(View.VISIBLE);
    }

    private void drawCardOrder() {
        DetailOrderCard card = new DetailOrderCard(this, mData.Detail);
        card.init();
        mCardOrder.setCard(card);
        mCardOrder.setVisibility(View.VISIBLE);
    }

    private void showCancelDialog() {
        final List<ModelConfig.Cancel> list = mData.Config.getListCancel();
        if( list.size() == 0 ) {
            new MaterialDialog.Builder(this)
                    .content(R.string.failed_cancel_list)
                    .positiveText(R.string.close)
                    .show();
        } else {
            CharSequence[] titles = new CharSequence[list.size()];
            int index = 0;
            for(ModelConfig.Cancel item : list ) {
                titles[index++] = item.text;
            }
            new MaterialDialog.Builder(this)
                    .title(R.string.detail_dialog_cancel_title)
                    .items(titles)
                    .alwaysCallSingleChoiceCallback()
                    .itemsCallbackSingleChoice(-1, new MaterialDialog.ListCallbackSingleChoice() {
                        @Override
                        public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                            dialog.getActionButton(DialogAction.POSITIVE).setEnabled(which > -1);
                            return true;
                        }
                    })
                    .callback(new MaterialDialog.ButtonCallback() {
                        @Override
                        public void onPositive(MaterialDialog dialog) {
                            ModelConfig.Cancel cancel = list.get(dialog.getSelectedIndex());
                            requestModelCancel(cancel.id);
                        }
                    })
                    .showListener(new DialogInterface.OnShowListener() {
                        @Override
                        public void onShow(DialogInterface dialogInterface) {
                            if (dialogInterface instanceof MaterialDialog) {
                                ((MaterialDialog)dialogInterface).getActionButton(DialogAction.POSITIVE).setEnabled(false);
                            }
                        }
                    })
                    .positiveText(R.string.detail_dialog_cancel_text)
                    .negativeText(R.string.close)
                    .show();
        }
    }

    private void requestModelCancel(String cancel_id) {
        displayLoading(true);
        volleyer().get(makeUrl(Page.getCancel))
                .addHeader("id", mData.Detail.id)
                .addHeader("cancel", cancel_id)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        final ModelCancel cancel = new Gson().fromJson(response, ModelCancel.class);
                        new MaterialDialog.Builder(DetailActivity.this)
                                .content(cancel.message)
                                .positiveText(R.string.ok)
                                .cancelable(false)
                                .callback(new MaterialDialog.ButtonCallback() {
                                    @Override
                                    public void onPositive(MaterialDialog dialog) {
                                        if( cancel.success ) {
                                            mData.History.is_update = true;
                                            finish();
                                        }
                                    }
                                })
                                .show();
                    }
                })
                .execute();

    }

    private void requestModelDetail(String id) {
        displayLoading(true);

        Page page = page = Page.getDetail1;
        switch( id ) {
            case "1": page = Page.getDetail1; break;
            case "2": page = Page.getDetail2; break;
            case "3": page = Page.getDetail3; break;
        }

        volleyer().get(makeUrl(page))
                .addHeader("id", id)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.Detail = new Gson().fromJson(response, ModelDetail.class);
                        drawModelDetail();
                        displayLoading(false);
                    }
                })
                .execute();
    }

    private void requestModelConfig() {
        volleyer().get(makeUrl(Page.getConfig))
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.Config = new Gson().fromJson(response, ModelConfig.class);
                    }
                })
                .execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_detail, menu);

        // MenuItem item = menu.findItem(R.id.action_cancel);
        // item.setIcon(Common.getDrawableWithColorFilter(this, R.drawable.ic_cancel_white_48dp, Color.RED));
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case R.id.action_cancel:
                showCancelDialog();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showError() {
        new MaterialDialog.Builder(DetailActivity.this)
                .content(R.string.failed_detail_id)
                .positiveText(R.string.close)
                .cancelable(false)
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        finish();
                    }
                })
                .show();
    }
}
