package qtec.china.customer.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardArrayAdapter;
import it.gmariotti.cardslib.library.view.CardListView;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseFragment;
import qtec.china.customer.card.NoticeCard;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.model.ModelNotice;

import java.util.ArrayList;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class NoticeFragment extends BaseFragment {
    CardListView mList;
    View mRootView;
    boolean isRequest;

    public static NoticeFragment newInstance() {
        return new NoticeFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mActivity.setTitle(R.string.title_activity_notice);
        if(  mRootView == null ) {
            mRootView = inflater.inflate(R.layout.fragment_notice, container, false);
            initView(mRootView);
        }
        return mRootView;
    }

    private void initView(View root) {
        mList = (CardListView)root.findViewById(R.id.card_list);
        mList.setEmptyView(root.findViewById(R.id.empty_data));
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if( isRequest  ) {
            drawModelNotice();
        } else {
            requestModelNotice();
        }
    }

    private void requestModelNotice() {
        mActivity.displayLoading(true);
        volleyer().get(makeUrl(UrlHelper.Page.getNotice))
                .addHeader("id", mData.User.id)
                .withErrorListener(mActivity)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        isRequest = true;
                        mData.Notice = new Gson().fromJson(response, ModelNotice.class);
                        initCards();
                        drawModelNotice();
                        mActivity.displayLoading(false);
                    }
                })
                .execute();
    }

    private void drawModelNotice() {
        mList.deferNotifyDataSetChanged();
    }

    private void initCards() {
        ArrayList<Card> cards = new ArrayList<>();
        for(ModelNotice.Notice notice : mData.Notice.getList()) {
            NoticeCard card = new NoticeCard(mActivity, notice);
            cards.add(card);
        }
        mList.setAdapter(new CardArrayAdapter(getActivity(), cards));
    }
}
