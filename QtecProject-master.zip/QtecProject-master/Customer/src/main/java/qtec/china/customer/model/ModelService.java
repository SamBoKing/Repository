package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelService {
    public boolean is_load;

    public class Service {
        public String title;
        public String img;
        public String tel;
        public String detail;
    }

    List<Service> list = new ArrayList<>();
    public List<Service> getList() {
        return list;
    }
}
