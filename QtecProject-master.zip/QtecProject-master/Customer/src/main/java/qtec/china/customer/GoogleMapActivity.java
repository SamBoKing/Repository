package qtec.china.customer;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spanned;
import android.view.*;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.gson.Gson;
import com.google.maps.android.clustering.ClusterManager;
import com.orhanobut.logger.Logger;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import qtec.china.customer.adapter.DrawerMenuAdapter;
import qtec.china.customer.adapter.PlaceAutocompleteAdapter;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.googlemap.RiderClusterRenderer;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.helper.UrlHelper.Page;
import qtec.china.customer.model.ModelRider;
import qtec.china.customer.model.ModelRiderGoogle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;

public class GoogleMapActivity extends BaseActivity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        GoogleMap.OnMyLocationChangeListener,
        GoogleMap.OnMyLocationButtonClickListener,
        OnMapReadyCallback
{
    final int IMAGE_CHECK_TIME = 1000;
    final int IMAGE_CHECK_COUNT = 3;

    // Google Map
    private GoogleMap mMap;
    private GoogleApiClient mClient;
    private Location mLocation;
    private boolean isConnected;
    private ModelRiderGoogle mModel;
    private ClusterManager<ModelRiderGoogle.Rider> mClusterManager;
    private List<Target> mTargetList = new ArrayList<>();
    private int mImageCheckCount;

    // Search AotoComplet
    private SearchView mSearchView;
    private PlaceAutocompleteAdapter mPlaceAdapter;
    private MenuItem mSearchItem;
    private MenuItem mCallItem;

    // Drawer Layout
    private View mDrawer;
    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;




    // Toolbar
    private Toolbar mToolbar;

    final Integer[] drawerIcons = new Integer[] {
            R.drawable.abc_ic_clear_mtrl_alpha,
            R.drawable.abc_ic_clear_mtrl_alpha,
            R.drawable.abc_ic_clear_mtrl_alpha,
            R.drawable.abc_ic_clear_mtrl_alpha,
            R.drawable.abc_ic_clear_mtrl_alpha,
            R.drawable.abc_ic_clear_mtrl_alpha
    };

    // Debug Test
    private Random mRandom = new Random(1984);
    private static final LatLngBounds BOUNDS_GREATER_SYDNEY = new LatLngBounds(
            new LatLng(-34.041458, 150.790100), new LatLng(-33.682247, 151.383362));

    protected synchronized void buildGoogleApiClient() {
        mClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .enableAutoManage(this, 0 /* clientId */, this)
                .addApi(LocationServices.API)
                .addApi(Places.GEO_DATA_API)
                .build();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_googlemap);
        buildGoogleApiClient();

        initMap();
        initToolbar();
        initDrawer();
    }

    private void initMap() {
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    private void initToolbar() {
        mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch(item.getItemId()) {
                    case android.R.id.home:
                        if ( mDrawerLayout.isDrawerOpen(mDrawerList) ) {
                            mDrawerLayout.closeDrawer(mDrawerList);
                        } else {
                            mDrawerLayout.openDrawer(mDrawerList);
                        }
                        break;
                    case R.id.action_call:
                        showCall();
                        break;
                }
                return false;
            }
        });

        // Custom Drawer Menu Icon Option
        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initDrawer() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawer = findViewById(R.id.left_drawer);
        mDrawerList = (ListView) findViewById(R.id.drawer_list);

        DrawerMenuAdapter drawerAdapter = new DrawerMenuAdapter(this);
        mDrawerList.setAdapter(drawerAdapter);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar,
                R.string.drawer_open, R.string.drawer_close)
        {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
            }

            public void onDrawerClosed(View view) {
                mSearchItem.setVisible(true);
                mCallItem.setVisible(true);
            }

            public void onDrawerOpened(View drawerView) {
                onSearchViewClose();
                mSearchItem.setVisible(false);
                mCallItem.setVisible(false);
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void toggleDrawer() {
        if ( mDrawerLayout.isDrawerOpen(mDrawer) ) {
            mDrawerLayout.closeDrawer(mDrawer);
        } else {
            mDrawerLayout.openDrawer(mDrawer);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateMenuIcon();
    }

    private void updateMenuIcon() {
        if( mData.User.is_menu ) {
            ActionBar actionBar = getSupportActionBar();
            if( actionBar != null ) {
//                Drawable d = Common.getDrawableWithColorFilter(this, R.drawable.ic_playlist_add_white_24dp, Color.RED);
//                actionBar.setHomeAsUpIndicator(d);
            }
        } else {
            mDrawerToggle.syncState();
        }
    }

    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            ActionBar actionBar = getSupportActionBar();
            mDrawerLayout.closeDrawer(mDrawer);
            switch( position ) {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
            }
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed() {
        if ( mDrawerLayout.isDrawerOpen(mDrawer) ) {
            mDrawerLayout.closeDrawer(mDrawer);
        } else {
            showExit();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            toggleDrawer();
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMyLocationEnabled(true);
        mMap.setOnMyLocationChangeListener(this);
        mMap.setOnMyLocationButtonClickListener(this);
        mMap.getUiSettings().setZoomControlsEnabled(true);

        mClusterManager = new ClusterManager<>(this, mMap);
        mClusterManager.setRenderer(new RiderClusterRenderer(this, mMap, mClusterManager));
        mMap.setOnCameraChangeListener(mClusterManager);
        mMap.setOnMarkerClickListener(mClusterManager);
        mMap.setOnInfoWindowClickListener(mClusterManager);

        mClient.connect();
    }

    private void moveLocation() {
        if( mLocation == null ) {
            Logger.e("Not Found Location!");
            return;
        }

        LatLng latlng = new LatLng(mLocation.getLatitude(), mLocation.getLongitude());
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng, getResources().getInteger(R.integer.map_defuault_zoom)));
    }

    private void requestModel() {
        if( mLocation == null ) {
            Logger.e("Not Found Location!");
            return;
        }

        displayLoading(true);
        volleyer().get(UrlHelper.makeUrl(Page.getRider))
                .addHeader("lat", mLocation.getLatitude() + "")
                .addHeader("lng", mLocation.getLongitude() + "")
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mModel = new Gson().fromJson(response, ModelRiderGoogle.class);
                        initModel();
                    }
                })
                .execute();
    }

    private void initModel() {
        loadImage();
        checkImage();
    }

    private void drawModel() {
        LatLngBounds.Builder bounds = new LatLngBounds.Builder();
        mClusterManager.clearItems();
        for(ModelRiderGoogle.Rider r : mModel.getList()) {
            mClusterManager.addItem(r);
            bounds.include(r.getPosition());
        }
        mClusterManager.cluster();
        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(),
                getResources().getInteger(R.integer.map_bounds_padding)));

        displayLoading(false);
    }


    private void loadImage() {
        int w = (int)getResources().getDimension(R.dimen.marker_width);
        int h = (int)getResources().getDimension(R.dimen.marker_height);

        for( final ModelRiderGoogle.Rider r : mModel.getList() ) {
            r.setPosition(position());
            Target target = new Target() {
                @Override
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                    r.bitmap = bitmap;
                    mTargetList.remove(this);
                }
                @Override
                public void onBitmapFailed(Drawable errorDrawable) {
                    mTargetList.remove(this);
                }
                @Override
                public void onPrepareLoad(Drawable placeHolderDrawable) { }
            };
            // 강한 참조를 만들기 위한 로직
            mTargetList.add(target);

            Picasso.with(this).load(r.url).resize(w, h).into(target);
        }
    }

    private void checkImage() {
        int count = 0;
        for(ModelRiderGoogle.Rider r : mModel.getList()) {
            if( r.bitmap != null ) count++;
        }

        if( mModel.getList().size() == count || mImageCheckCount++ > IMAGE_CHECK_COUNT ) {
            mImageCheckCount = 0;
            drawModel();
        } else {
            new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    checkImage();
                    super.handleMessage(msg);
                }
            }.sendEmptyMessageDelayed(0, IMAGE_CHECK_TIME);
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        if( isConnected ) {
            Logger.i("ReConnected");
            return;
        }

        mLocation = LocationServices.FusedLocationApi.getLastLocation(mClient);
        if( mLocation == null ) {
            new MaterialDialog.Builder(this)
                    .content(R.string.failed_location_connect)
                    .positiveText(R.string.ok)
                    .show();
        } else {
            moveLocation();
            requestModel();
        }
        isConnected = true;
    }

    @Override
    public void onConnectionSuspended(int i) {
        Logger.i("ConnectionSuspended");
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        new MaterialDialog.Builder(GoogleMapActivity.this)
                .content(getString(R.string.failed_google_connect, connectionResult.getErrorCode()))
                .positiveText(R.string.ok)
                .show();
    }

    @Override
    public void onMyLocationChange(Location location) {
        if( mLocation == null && location != null ) {
            mLocation = location;
            moveLocation();
            requestModel();
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        return false;
    }

    public void onSearchViewClose() {
        hideKeyboard();
        if (mSearchItem != null) {
            mSearchItem.collapseActionView();
        }

        if( mSearchView != null ) {
            mSearchView.setQuery("", false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_map, menu);

        mCallItem = menu.findItem(R.id.action_call);
        mSearchItem = menu.findItem(R.id.action_search);
        mSearchView = (SearchView) MenuItemCompat.getActionView(mSearchItem);
        // Searchable Xml Setting
        if( mSearchView != null ) {
            SearchView.SearchAutoComplete searchText = (SearchView.SearchAutoComplete) mSearchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
            searchText.setOnItemClickListener(mAutocompleteClickListener);
            mPlaceAdapter = new PlaceAutocompleteAdapter(this, android.R.layout.simple_list_item_1,
                    mClient, BOUNDS_GREATER_SYDNEY, null);
            searchText.setAdapter(mPlaceAdapter);
        }
        // Searchable Custom Setting
        // setupSearchView();
        return true;
    }

    private AdapterView.OnItemClickListener mAutocompleteClickListener
            = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            /*
             Retrieve the place ID of the selected item from the Adapter.
             The adapter stores each Place suggestion in a PlaceAutocomplete object from which we
             read the place ID.
              */
            final PlaceAutocompleteAdapter.PlaceAutocomplete item = mPlaceAdapter.getItem(position);
            final String placeId = String.valueOf(item.placeId);
            Logger.i("Autocomplete item selected: " + item.description);

            /*
             Issue a request to the Places Geo Data API to retrieve a Place object with additional
              details about the place.
              */
            PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi
                    .getPlaceById(mClient, placeId);
            placeResult.setResultCallback(mUpdatePlaceDetailsCallback);

            Toast.makeText(getApplicationContext(), "Clicked: " + item.description,
                    Toast.LENGTH_SHORT).show();
            Logger.i("Called getPlaceById to get Place details for " + item.placeId);
        }
    };

    /**
     * Callback for results from a Places Geo Data API query that shows the first place result in
     * the details view on screen.
     */
    private ResultCallback<PlaceBuffer> mUpdatePlaceDetailsCallback
            = new ResultCallback<PlaceBuffer>() {
        @Override
        public void onResult(PlaceBuffer places) {
            if (!places.getStatus().isSuccess()) {
                // Request did not complete successfully
                Logger.e("Place query did not complete. Error: " + places.getStatus().toString());
                places.release();
                return;
            }
            // Get the Place object from the buffer.
            final Place place = places.get(0);

            // Format details of the place for display and show it in a TextView.
            if( mLocation == null ) {
                mLocation = new Location(LocationManager.PASSIVE_PROVIDER);
            }
            mLocation.setLatitude(place.getLatLng().latitude);
            mLocation.setLongitude(place.getLatLng().longitude);
            requestModel();

            Logger.i("Place details received: " + place.getName());
            places.release();
        }
    };

    private static Spanned formatPlaceDetails(Resources res, CharSequence name, String id, CharSequence address, CharSequence phoneNumber, Uri websiteUri) {
        return Html.fromHtml(res.getString(R.string.place_details, name, id, address, phoneNumber, websiteUri));
    }

    private LatLng position() {
        return new LatLng(
                random(mLocation.getLatitude() + 0.3, mLocation.getLatitude() - 0.3),
                random(mLocation.getLongitude() + 0.3, mLocation.getLongitude() - 0.3)
        );
    }

    private double random(double min, double max) {
        return mRandom.nextDouble() * (max - min) + min;
    }
}
