package qtec.china.customer.model;

public class ModelCharging {
    public boolean success;
    public String message;
    public int mileage;
}
