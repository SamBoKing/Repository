package qtec.china.customer.model;

import android.graphics.Bitmap;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

import java.util.ArrayList;
import java.util.List;

public class ModelRiderGoogle {
    public static class Rider implements ClusterItem {
        public String id;
        public String name;
        public String memo;
        public String url;
        public double lat;
        public double lng;
        public int rating;

        public Bitmap bitmap;

        @Override
        public LatLng getPosition() {
            return new LatLng(lat, lng);
        }

        public void setPosition(LatLng latlng) {
            lat = latlng.latitude;
            lng = latlng.longitude;
        }
    }

    List<Rider> list = new ArrayList<>();
    public List<Rider> getList() {
        return list;
    }
}
