package qtec.china.customer.card;

import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.squareup.picasso.Picasso;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import it.gmariotti.cardslib.library.prototypes.CardWithList;
import it.gmariotti.cardslib.library.prototypes.LinearListView;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.dialog.LoginDialog;
import qtec.china.customer.model.ModelResult;
import qtec.china.customer.model.ModelUser;

import java.util.ArrayList;
import java.util.List;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.Page;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class UserCard extends CardWithList {
    private BaseActivity mContext;
    private ModelUser mItem;
    public UserCard(BaseActivity context, ModelUser item) {
        super(context);
        mContext = context;
        mItem = item;
    }

    @Override
    protected CardHeader initCardHeader() {
        CardHeader header = new CardHeader(mContext, R.layout.card_header_inner_user) {
            @Override
            public void setupInnerViewElements(ViewGroup parent, View view) {
                super.setupInnerViewElements(parent, view);

                if( !StringUtils.isEmpty(mItem.img) ) {
                    RoundedImageView img = (RoundedImageView) view.findViewById(R.id.user_img);
                    Picasso.with(mContext).load(mItem.img).fit().into(img);
                }

                TextView title = (TextView) view.findViewById(R.id.card_header_inner_title);
                TextView subTitle = (TextView) view.findViewById(R.id.card_header_inner_subtitle);
                if( title != null ) title.setText(mItem.name);
                if( subTitle != null ) subTitle.setText(mItem.level);
            }
        };
        return header;
    }

    @Override
    protected void initCard() { }

    @Override
    protected List<ListObject> initChildren() {
        List<ListObject> mObjects = new ArrayList<>();

        CharSequence[] titles =  getContext().getResources().getTextArray(R.array.user_info_titles);
        for(int i = 0; i < titles.length; i++) {
            mObjects.add(new UserObject(this, i, titles[i].toString()));
        }
        return mObjects;
    }

    public class UserObject extends DefaultListObject {
        private int mIndex;
        private String mTitle;
        private String mName;
        public UserObject(Card parentCard, int index, String title) {
            super(parentCard);
            mIndex = index;
            mTitle = title;
            init();
        }

        public void init() {
            setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(LinearListView linearListView, View view, int i, ListObject listObject) {
                    switch( mIndex ) {
                        case 0:
                            showNameDialog();
                            break;
                        case 1:
                            LoginDialog login = new LoginDialog();
                            login.setReLogin(true);
                            login.setOnLoginListener(new LoginDialog.LoginListener() {
                                @Override
                                public void onLoginSuccess() {
                                    mItem = mContext.mData.User;
                                    notifyDataSetChanged();
                                }
                            });
                            login.show(mContext.getSupportFragmentManager(), "login");
                            break;
                    }
                }
            });
        }

        private void showNameDialog() {
            new MaterialDialog.Builder(mContext)
                    .title(R.string.user_edit_name_title)
                    .content(R.string.user_edit_name_subtitle)
                    .inputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PERSON_NAME)
                    .positiveText(R.string.save)
                    .negativeText(R.string.close)
                    .alwaysCallInputCallback() // this forces the callback to be invoked with every input change
                    .input(mContext.getString(R.string.user_edit_name_hint), mItem.name, false, new MaterialDialog.InputCallback() {
                        @Override
                        public void onInput(MaterialDialog dialog, CharSequence input) {
                            mName = input.toString();
                            dialog.getActionButton(DialogAction.POSITIVE).setEnabled(input.length() > 0);
                        }
                    })
                    .callback(new MaterialDialog.ButtonCallback() {
                        @Override
                        public void onPositive(MaterialDialog dialog) {
                            requestName();
                        }
                    })
                    .show();
        }

        private void requestName() {
            mContext.displayLoading(true);
            volleyer().get(makeUrl(Page.getResult))
                    .addHeader("id", mItem.id)
                    .addHeader("name", mName)
                    .withErrorListener(mContext)
                    .withListener(new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            ModelResult result = new Gson().fromJson(response, ModelResult.class);
                            if( result.success ) {
                                mItem.name = mName;
                                notifyDataSetChanged();
                            }
                            mContext.displayLoading(false);
                        }
                    })
                    .execute();
        }
    }

    @Override
    public void setOnClickListener(OnCardClickListener onClickListener) {
        super.setOnClickListener(onClickListener);
    }

    @Override
    public int getChildLayoutId() { return R.layout.card_main_inner_user; }

    @Override
    public View setupChildView(int i, ListObject listObject, View view, ViewGroup viewGroup) {
        TextView title = (TextView) view.findViewById(R.id.txt_title);
        TextView data = (TextView) view.findViewById(R.id.txt_data);
        ImageView icon = (ImageView) view.findViewById(R.id.card_arrow);
        LinearLayout layout_payment = (LinearLayout) view.findViewById(R.id.layout_payment);
        layout_payment.setVisibility(View.GONE);


        if( listObject instanceof UserObject ) {
            UserObject user = ((UserObject)listObject);
            title.setText(user.mTitle);
            switch( user.mIndex  ) {
                case 0:
                    icon.setVisibility(View.VISIBLE);
                    data.setText(mItem.name);
                    break;
                case 1:
                    icon.setVisibility(View.VISIBLE);
                    data.setText(mItem.phone);
                    break;
                case 2:
                    icon.setVisibility(View.INVISIBLE);
                    data.setText(mItem.mileage + "");
                    break;
                case 3:
                    icon.setVisibility(View.INVISIBLE);
                    data.setVisibility(View.GONE);
                    layout_payment.setVisibility(View.VISIBLE);

                    CheckBox pay1 = (CheckBox) view.findViewById(R.id.ckb_pay1);
                    CheckBox pay2 = (CheckBox) view.findViewById(R.id.ckb_pay2);
                    CheckBox pay3 = (CheckBox) view.findViewById(R.id.ckb_pay3);
                    pay1.setChecked(mItem.payment1);
                    pay2.setChecked(mItem.payment2);
                    pay3.setChecked(mItem.payment3);
                    break;
            }
        }
        return view;
    }
}
