package qtec.china.customer.model;

public class ModelLogin {
    public String id;
    public boolean login;
    public String message;
}
