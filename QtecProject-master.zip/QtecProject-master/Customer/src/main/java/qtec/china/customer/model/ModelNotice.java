package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelNotice {

    public static class Notice {
        public String id;
        public String title;
        public String url;
        public boolean read;
    }

    List<Notice> list = new ArrayList<>();
    public List<Notice> getList() {
        return list;
    }

    public boolean isRead() {
        for(Notice notice : list) {
            if( !notice.read ) {
                return false;
            }
        }
        return true;
    }
}
