package qtec.china.customer.application;

import android.app.Application;
import com.baidu.mapapi.SDKInitializer;
import com.orhanobut.logger.LogLevel;
import com.orhanobut.logger.Logger;
import qtec.china.customer.R;
import qtec.china.customer.manager.VolleyManager;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class App extends Application {
    private final String TAG = "KJS";
    @Override
    public void onCreate() {
        super.onCreate();
        Logger.init(TAG).setLogLevel(LogLevel.FULL);
        SDKInitializer.initialize(this);
        VolleyManager.init(this);
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                        .setDefaultFontPath("fonts/Roboto-Regular.ttf")
                        .setFontAttrId(R.attr.fontPath)
                        .build()
        );
    }
}
