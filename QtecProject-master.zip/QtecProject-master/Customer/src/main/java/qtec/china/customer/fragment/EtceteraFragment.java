package qtec.china.customer.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardArrayAdapter;
import it.gmariotti.cardslib.library.view.CardListView;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseFragment;
import qtec.china.customer.card.EtceteraCard;
import qtec.china.customer.object.EtceteraItem;

import java.util.ArrayList;

public class EtceteraFragment extends BaseFragment {

    EtceteraItem[] menus = new EtceteraItem[] {
            new EtceteraItem(R.drawable.ic_content_paste_grey600_48dp,
                    R.string.etcetera_menu_agreement_title,
                    R.string.etcetera_menu_agreement_subtitle,
                    true),

            new EtceteraItem(R.drawable.ic_business_grey600_48dp,
                    R.string.etcetera_menu_company_title,
                    R.string.etcetera_menu_company_subtitle,
                    true),

            new EtceteraItem(R.drawable.ic_face_grey600_48dp,
                    R.string.etcetera_menu_call_title,
                    R.string.etcetera_menu_call_subtitle,
                    false),

            new EtceteraItem(R.drawable.ic_send_grey600_48dp,
                    R.string.etcetera_menu_email_title,
                    R.string.etcetera_menu_email_subtitle,
                    false)
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_etcetera, container, false);
        getActivity().setTitle(R.string.title_activity_etcetera);
        initCards(rootView);
        return rootView;
    }

    private void initCards(View root) {
        ArrayList<Card> cards = new ArrayList<>();
        for(int i = 0; i < menus.length; i++) {
            EtceteraCard card = new EtceteraCard(mActivity, menus[i]);
            card.setId(i + "");
            cards.add(card);
        }

        CardListView list = (CardListView) root.findViewById(R.id.card_list);
        if ( list != null ){
            list.setAdapter(new CardArrayAdapter(getActivity(), cards));
        }
    }
}
