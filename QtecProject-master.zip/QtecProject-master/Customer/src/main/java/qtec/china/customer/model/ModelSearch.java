package qtec.china.customer.model;

import android.database.Cursor;
import android.database.MatrixCursor;
import com.baidu.mapapi.search.sug.SuggestionResult;

import java.util.ArrayList;
import java.util.List;

import static com.baidu.mapapi.search.sug.SuggestionResult.*;

public class ModelSearch {
    private final String _ID = "_id";
    private final String TITLE = "title";
    private final String SUMMARY = "summary";
    private final String X = "x";
    private final String Y = "y";

    private String[] colums = new String[] { "_id", "title", "summary", "x", "y" };

    public static class Search {
        public String title;
        public String summary;
        public float x;
        public float y;
    }

    List<Search> list = new ArrayList<>();
    public List<Search> getList() {
        return list;
    }

    public void updateList(List<SuggestionResult.SuggestionInfo> results) {
        list.clear();
        if( results != null ) {
            for (SuggestionInfo info : results) {
                Search search = new Search();
                search.title = info.city;
                search.summary = info.district + ", " + info.key;
                this.list.add(search);
            }
        }
    }

    public void clearList() {
        if( list != null ) {
            list.clear();
        }
    }

    // TODO : Test Logic
    public void updateList(String search) {
        int index = 0;
        for(Search s : list) {
            s.title = "Title : " + search + " - " + (++index);
        }
    }

    public Cursor getCursor() {
        if( list == null ) {
            return null;
        }

        MatrixCursor cursor = new MatrixCursor(colums);
        int index = 0;
        for(Search s : list) {
            cursor.addRow( new Object[] { index, s.title, s.summary, s.x, s.y } );
        }
        return cursor;
    }

    public Search convert(Cursor cursor) {
        Search value = new Search();
        value.title = cursor.getString(cursor.getColumnIndex(TITLE));
        value.summary = cursor.getString(cursor.getColumnIndex(SUMMARY));
        value.x = cursor.getFloat(cursor.getColumnIndex(X));
        value.y = cursor.getFloat(cursor.getColumnIndex(Y));
        return value;
    }
}
