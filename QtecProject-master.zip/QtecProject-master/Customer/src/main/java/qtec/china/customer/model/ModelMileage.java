package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelMileage {
    public class Mileage {
        public String color;
        public String data1;
        public String data2;
        public String data3;
    }

    public String total;
    List<Mileage> list = new ArrayList<>();
    public List<Mileage> getList() {
        return list;
    }
}
