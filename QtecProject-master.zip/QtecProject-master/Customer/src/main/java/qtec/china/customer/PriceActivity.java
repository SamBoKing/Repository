package qtec.china.customer;

import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.orhanobut.logger.Logger;
import qtec.china.customer.adapter.PricePagerAdapter;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.custom.SlidingTabLayout;
import qtec.china.customer.model.ModelPrice;

import java.util.List;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;
import static qtec.china.customer.helper.UrlHelper.makeUrl;


public class PriceActivity extends BaseActivity {
    private SlidingTabLayout mSlidingTabLayout;
    private PricePagerAdapter mAdapter;
    private ViewPager mViewPager;
    private ModelPrice.Area mArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price);
        initToolbar();
        initPager();
        if( mData.Price.is_load ){
            drawModelPrice();
        } else {
            requestModelPrice();
        }
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initPager() {
        mViewPager = (ViewPager) findViewById(R.id.pager);

        mSlidingTabLayout = (SlidingTabLayout) findViewById(R.id.sliding_tabs);
        ColorStateList colors = Common.getStatListColorWithAlpha(getResources().getColor(R.color.appThemeToolbarTextColor), 0.5f);
        mSlidingTabLayout.setTextColor(colors);
        mSlidingTabLayout.setBackgroundColor(getResources().getColor(R.color.appThemeColor));
        mSlidingTabLayout.setSelectedIndicatorColors(getResources().getColor(R.color.appThemeToolbarTextColor));
        mSlidingTabLayout.setDistributeEvenly(true);
    }

    private void requestModelPrice() {
        displayLoading(true);
        volleyer().get(makeUrl(Page.getPrice))
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        mData.Price = new Gson().fromJson(response, ModelPrice.class);
                        mData.Price.is_load = true;
                        drawModelPrice();
                    }
                })
                .execute();
    }

    private void drawModelPrice() {
        if( mData.Price.getList() == null ) {
            Logger.e("Price list is null");
            return;
        }

        if( mArea == null ) {
            mArea = mData.Price.getItem(0);
            if( mArea == null ) {
                Logger.e("Area is null");
                return;
            }
        }
        setTitle(getString(R.string.title_activity_price) + " - " + mArea.title);
        mAdapter = new PricePagerAdapter(getSupportFragmentManager(), mArea.getList());
        mViewPager.setAdapter(mAdapter);
        mSlidingTabLayout.setViewPager(mViewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_price, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case android.R.id.home:
                finish();
                break;
            case R.id.action_area:
                showArea();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showArea() {
        List<ModelPrice.Area> list = mData.Price.getList();
        if( list == null ) {
            SnackbarManager.show(
                    Snackbar.with(this)
                            .colorResource(R.color.appThemeColor)
                            .textColorResource(R.color.textColorPrimary)
                            .text(R.string.failed_area_list)
                            .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                            .textTypeface(Typeface.DEFAULT_BOLD)
            );
        } else {
            CharSequence[] items = new CharSequence[list.size()];
            for(int i = 0; i < list.size(); i++) {
                items[i] = list.get(i).title;
            }

            new MaterialDialog.Builder(this)
                    .title(R.string.price_area_select)
                    .positiveText(R.string.close)
                    .items(items)
                    .itemsCallback(new MaterialDialog.ListCallback() {
                        @Override
                        public void onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                            ModelPrice.Area area = mData.Price.getItem(which);
                            if (!area.equals(mArea)) {
                                mArea = area;
                                drawModelPrice();
                            }
                        }
                    })
                    .show();
        }
    }
}
