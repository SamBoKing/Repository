package qtec.china.customer.model;

public class ModelRating {
    public boolean success;
    public String message;
}
