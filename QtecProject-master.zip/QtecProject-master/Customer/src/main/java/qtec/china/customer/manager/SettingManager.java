package qtec.china.customer.manager;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import qtec.china.customer.R;

public class SettingManager {
    public static SettingManager _instance;
    public static SettingManager getInstance(Context context) {
        if( _instance == null ) {
            _instance = new SettingManager(context);
        }
        return _instance;
    }

    public static void release() {
        if( _instance != null ) {
            _instance = null;
        }
    }

    private Context mContext;
    private String mUserId;
    public SettingManager(Context context) {
        this.mContext = context;
        init();
    }

    private void init() {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mContext);
        mUserId = pref.getString(mContext.getString(R.string.key_user_id), "");
    }

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String id) {
        mUserId = id;
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString(mContext.getString(R.string.key_user_id), id);
        edit.commit();
    }

    public String getQRCode(int key) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mContext);
        return pref.getString(mContext.getString(key), "");
    }

    public void setQRCode(int key, String uri) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor edit = pref.edit();
        edit.putString(mContext.getString(key), uri);
        edit.commit();
    }
}
