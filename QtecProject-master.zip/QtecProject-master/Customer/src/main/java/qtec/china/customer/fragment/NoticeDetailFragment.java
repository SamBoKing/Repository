package qtec.china.customer.fragment;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.orhanobut.logger.Logger;
import qtec.china.customer.R;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.model.ModelNotice;
import qtec.china.customer.model.ModelResult;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class NoticeDetailFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, Response.ErrorListener {
    private SwipeRefreshLayout mRefresh;
    private WebView mWebView;
    private ModelNotice.Notice mNotice;
    private boolean isStop;

    public static NoticeDetailFragment newInstance(ModelNotice.Notice notice) {
        NoticeDetailFragment detail = new NoticeDetailFragment();
        detail.setArguments(notice);
        return detail;
    }

    public void setArguments(ModelNotice.Notice notice) {
        this.mNotice = notice;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_notice_detail, container, false);
        getActivity().setTitle(mNotice.title);
        initView(rootView);
        loadUrl();
        return rootView;
    }

    private void initView(View root) {
        mRefresh = (SwipeRefreshLayout) root.findViewById(R.id.swipe_container);
        mRefresh.setOnRefreshListener(this);
        mRefresh.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        mWebView = (WebView) root.findViewById(R.id.web);
        mWebView.setWebChromeClient(new MyBrowserChrome());
        mWebView.setWebViewClient(new MyBrowser());
        mWebView.getSettings().setLoadsImagesAutomatically(true);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }

    private void loadUrl() {
        mRefresh.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        mRefresh.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                        mRefresh.setRefreshing(true);
                    }
                });

        // mRefresh.setRefreshing(true);
        if( !mNotice.read ) {
            volleyer().get(makeUrl(UrlHelper.Page.getResult))
                    .addHeader("id", mNotice.id)
                    .withErrorListener(this)
                    .withListener(new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            ModelResult result = new Gson().fromJson(response, ModelResult.class);
                            mNotice.read = result.success;
                            mWebView.loadUrl(mNotice.url);
                        }
                    })
                    .execute();
        } else {
            mWebView.loadUrl(mNotice.url);
        }
    }

    @Override
    public void onRefresh() {
        mWebView.reload();
    }

    @Override
    public void onResume() {
        super.onResume();
        isStop = false;
    }

    @Override
    public void onStop() {
        super.onStop();
        isStop = true;
        mWebView.stopLoading();
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Logger.e("onErrorResponse : %s  " + error.getMessage());
        showError();
    }

    private class MyBrowserChrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) { }
    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            mRefresh.setRefreshing(false);
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            Logger.e("onReceivedError : %d, %s, %s  ", errorCode, description, failingUrl);
            try {
                if( !isStop ) {
                    mRefresh.setRefreshing(false);
                    showError();
                }
            } catch (Exception e) {
                Logger.e("onReceivedError : " + e);
            }
        }
    }

    public void showError() {
        new MaterialDialog.Builder(getActivity())
                .content(R.string.failed_network_connect)
                .positiveText(R.string.ok)
                .dismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        getFragmentManager().popBackStack();
                    }
                })
                .show();
    }
}
