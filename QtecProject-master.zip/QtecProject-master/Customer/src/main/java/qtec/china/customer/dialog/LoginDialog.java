package qtec.china.customer.dialog;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.gc.materialdesign.views.ButtonRectangle;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.Volleyer;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import qtec.china.customer.BaiduMapActivity;
import qtec.china.customer.R;
import qtec.china.customer.UserActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.helper.UrlHelper.Page;
import qtec.china.customer.manager.DataManager;
import qtec.china.customer.manager.SettingManager;
import qtec.china.customer.model.ModelCert;
import qtec.china.customer.model.ModelLogin;
import qtec.china.customer.model.ModelUser;

public class LoginDialog extends DialogFragment implements SwipeRefreshLayout.OnRefreshListener, Response.ErrorListener {

    final int MIN_PHONE_LENGTH = 8;
    final int MAX_CRET_LENGTH = 6;

    private boolean mReLogin;
    private SettingManager mSetting;
    private DataManager mData;
    private MaterialDialog mDialog;
    private EditText mEditPhone;
    private EditText mEditCret;
    private ButtonRectangle mBtnCret;
    private View mPositive;
    private SwipeRefreshLayout mSwipeLayout;
    private String mCretNum;
    private String mPhoneNum;
    private LoginListener mListener;

    public interface LoginListener {
        void onLoginSuccess();
    }

    public LoginDialog() {
        mData = DataManager.getInstance();
        mSetting = SettingManager.getInstance(getActivity());
    }

    public void setReLogin(boolean bReLogin) {
        mReLogin = bReLogin;
    }

    public void setOnLoginListener(LoginListener listenser) {
        mListener = listenser;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        mDialog = new MaterialDialog.Builder(getActivity())
                .title(mReLogin ? R.string.login_re_dialog_title : R.string.login_dialog_title)
                .customView(R.layout.dialog_login, false)
                .positiveText(mReLogin ? R.string.relogin : R.string.login)
                .negativeText(R.string.close)
                .cancelable(false)
                .autoDismiss(false)
                .showListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialogInterface) {
                        mPositive.setEnabled(false);
                    }
                })
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        requestModelLogin();
                    }

                    @Override
                    public void onNegative(MaterialDialog dialog) {
                        dialog.dismiss();
                    }
                })
                .build();

        View root = mDialog.getCustomView();
        mPositive = mDialog.getActionButton(DialogAction.POSITIVE);
        mSwipeLayout = (SwipeRefreshLayout) root.findViewById(R.id.swipe_container);
        mSwipeLayout.setOnRefreshListener(this);
        mSwipeLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light,
                android.R.color.holo_red_light);
        mSwipeLayout.setEnabled(false);

        mEditPhone = (EditText) root.findViewById(R.id.edit_phone_num);
        mEditPhone.setImeOptions(EditorInfo.IME_ACTION_DONE);

        mEditCret = (EditText) root.findViewById(R.id.edit_cret_num);
        mEditCret.setImeOptions(EditorInfo.IME_ACTION_DONE);
        mEditCret.setFilters(new InputFilter[] { new InputFilter.LengthFilter(MAX_CRET_LENGTH) });
        mEditCret.setEnabled(false);

        mBtnCret = (ButtonRectangle) root.findViewById(R.id.btn_cret);
        mBtnCret.setEnabled(false);
        mBtnCret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestModelCret();
            }
        });

        mEditPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mBtnCret.setEnabled(s.toString().trim().length() >= MIN_PHONE_LENGTH);
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        mEditPhone.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    if( mBtnCret.isEnabled() ) {
                        requestModelCret();
                    } else {
                        mEditPhone.setError(getString(R.string.login_dialog_fail_phone));
                    }
                    return true;
                }
                return false;
            }
        });

        mEditCret.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mPositive.setEnabled(s.toString().trim().length() == MAX_CRET_LENGTH);
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });


        mEditCret.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    if( mPositive.isEnabled() ) {
                        requestModelLogin();
                    } else {
                        mEditCret.setError(getString(R.string.login_dialog_fail_cert));
                    }
                    return true;
                }
                return false;
            }
        });

        mDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        return mDialog;
    }

    private void requestModelCret() {
        mEditPhone.setError(null);
        mEditPhone.clearFocus();

        displayLoading(true);
        Volleyer.volleyer().get(UrlHelper.makeUrl(Page.getCret))
                .addHeader("phone", mEditPhone.getText().toString())
                .withErrorListener(LoginDialog.this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        ModelCert auth = new Gson().fromJson(response, ModelCert.class);
                        if( auth.result ) {
                            mPhoneNum = mEditPhone.getText().toString();
                            mEditCret.setEnabled(true);
                            mEditCret.requestFocus();

                            // TODO : Test Code
                            mCretNum = getCretNum();
                            showNotification();
                        }
                        // else ??
                    }
                }).execute();
    }

    private void requestModelLogin() {
        mEditCret.setError(null);

        String cret = mEditCret.getText().toString();
        // TODO : Test Code
        if( !mCretNum.equals(cret) ) {
            showMessage(android.R.color.holo_red_light, "인증번호가 잘못되었습니다!");
            return;
        }

        displayLoading(true);
        Volleyer.volleyer().get(UrlHelper.makeUrl(Page.getLogin))
                .addHeader("id", mReLogin ? "" : mData.User.id)
                .addHeader("phone", mPhoneNum)
                .addHeader("cert", mCretNum)
                .withErrorListener(LoginDialog.this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        ModelLogin login = new Gson().fromJson(response, ModelLogin.class);
                        if (login.login) {
                            // Save User Id
                            mSetting.setUserId(login.id);
                            requestModelUser(login.id);
                        } else {
                            displayLoading(false);
                            showMessage(android.R.color.holo_red_light, login.message);
                        }
                    }
                }).execute();
    }

    private void requestModelUser(String id) {
        Volleyer.volleyer().get(UrlHelper.makeUrl(mReLogin ? Page.getReUser : Page.getUser))
                .addHeader("id", id)
                .withErrorListener(LoginDialog.this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.User = new Gson().fromJson(response, ModelUser.class);
                        displayLoading(false);

                        if (mListener != null) {
                            mListener.onLoginSuccess();
                        }

                        if (mDialog.isShowing()) {
                            mDialog.dismiss();
                        }
                    }
                }).execute();
    }

    private void displayLoading(boolean show) {
        mSwipeLayout.setEnabled(show);
        mSwipeLayout.setRefreshing(show);
    }

    private void showMessage(int resColor, String message) {
        ViewGroup view = (ViewGroup)mDialog.findViewById(R.id.customViewFrame);

        SnackbarManager.show(
                Snackbar.with(getActivity())
                        .colorResource(resColor)
                        .textColorResource(R.color.textColorPrimary)
                        .text(message)
                        .margin(Common.getDimension(getActivity(), 20))
                        .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                        .textTypeface(Typeface.DEFAULT_BOLD)
        ,view, true);
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        this.setCancelable(false);
        super.show(manager, tag);
    }

    @Override
    public void onRefresh() { }

    @Override
    public void onErrorResponse(VolleyError error) {
        displayLoading(false);
        showMessage(android.R.color.holo_red_light, getString(R.string.failed_network_connect) );
    }

    // TODO : Test Function
    private String getCretNum() {
        String number = "";
        for(int i = 0; i < MAX_CRET_LENGTH; i++) {
            int n = (int)(Math.random() * 10);
            number += n;
        }
        return number;
    }

    // TODO : Test Function
    private void showNotification() {
        NotificationManager nm = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent pendingIntent = PendingIntent.getActivity(getActivity(), 0, new Intent(getActivity(),
                mReLogin ? UserActivity.class : BaiduMapActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mCompatBuilder = new NotificationCompat.Builder(getActivity());
        mCompatBuilder.setSmallIcon(R.mipmap.ic_launcher);
        mCompatBuilder.setTicker("인증번호가 발송되었습니다.");
        mCompatBuilder.setWhen(System.currentTimeMillis());
        mCompatBuilder.setNumber(1);
        mCompatBuilder.setContentTitle("인증번호 : " + mCretNum);
        mCompatBuilder.setContentText("인증번호 입력후 로그인 진행해 주세요.");
        mCompatBuilder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        mCompatBuilder.setContentIntent(pendingIntent);
        mCompatBuilder.setAutoCancel(true);

        nm.notify(8572, mCompatBuilder.build());
    }
}
