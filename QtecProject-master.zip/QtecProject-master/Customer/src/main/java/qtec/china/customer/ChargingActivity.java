package qtec.china.customer;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.*;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.gc.materialdesign.views.ButtonRectangle;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.Volleyer;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.orhanobut.logger.Logger;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.model.ModelCharging;

import static qtec.china.customer.helper.UrlHelper.Page;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class ChargingActivity extends BaseActivity implements View.OnClickListener {
    final int MIN_MONEY = 100;

    TextView mTextPhone;
    EditText mEditMoney;
    RadioGroup mRadioPayment;
    ButtonRectangle mButtonCharging;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charging);
        initToolbar();
        initView();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.layout_toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initView() {
        mTextPhone = (TextView)findViewById(R.id.text_phone);
        // mTextPhone.setText(mData.User.phone);
        mTextPhone.setText("010-1234-5556");

        mEditMoney = (EditText)findViewById(R.id.edit_money);
        mEditMoney.clearFocus();

        mRadioPayment = (RadioGroup) findViewById(R.id.radio_group_payment);

        mButtonCharging = (ButtonRectangle) findViewById(R.id.button_charging);
        mButtonCharging.setRippleSpeed(500);
        mButtonCharging.setOnClickListener(this);

        findViewById(R.id.button_money1).setOnClickListener(this);
        findViewById(R.id.button_money2).setOnClickListener(this);
        findViewById(R.id.button_money3).setOnClickListener(this);
        findViewById(R.id.button_money4).setOnClickListener(this);
        findViewById(R.id.button_money5).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch( view.getId() ) {
            case R.id.button_money1:
                setPlusMoney(100);
                break;
            case R.id.button_money2:
                setPlusMoney(300);
                break;
            case R.id.button_money3:
                setPlusMoney(500);
                break;
            case R.id.button_money4:
                setPlusMoney(1000);
                break;
            case R.id.button_money5:
                setPlusMoney(3000);
                break;
            case R.id.button_charging:
                requestModelCharging();
                break;
        }
    }

    private void requestModelCharging() {
        String money = mEditMoney.getText().toString();
        if( StringUtils.isEmpty(money) ) {
            showError(R.string.charging_fail_money_empty);
            return;
        }

        if( Integer.parseInt(money) < MIN_MONEY ) {
            showError(R.string.charging_fail_money_min);
            return;
        }

        int payment_id = mRadioPayment.getCheckedRadioButtonId();
        if( payment_id == -1 ) {
            showError(R.string.charging_fail_payment);
            return;
        }

        String payment_type = "";
        switch ( payment_id ) {
            case R.id.radio_payment1: payment_type = "1"; break;
            case R.id.radio_payment2: payment_type = "2"; break;
        }

        displayLoading(true);
        Volleyer.volleyer().get(makeUrl(Page.getCharging))
                .addHeader("id", mData.User.id)
                .addHeader("money", money)
                .addHeader("payment", payment_type)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        final ModelCharging charging = new Gson().fromJson(response, ModelCharging.class);
                        new MaterialDialog.Builder(ChargingActivity.this)
                                .content(charging.message)
                                .positiveText(R.string.ok)
                                .cancelable(false)
                                .callback(new MaterialDialog.ButtonCallback() {
                                    @Override
                                    public void onPositive(MaterialDialog dialog) {
                                        if (charging.success) {
                                            mData.User.mileage = charging.mileage;
                                            // finish();
                                        }
                                    }
                                })
                                .show();
                    }
                }).execute();
    }

    public void showError(int textRes) {
        SnackbarManager.show(
                Snackbar.with(this)
                        .colorResource(R.color.md_deep_orange_500)
                        .textColorResource(R.color.textColorPrimary)
                        .text(textRes)
                        .margin(Common.getDimension(this, 20))
                        .position(Snackbar.SnackbarPosition.TOP)
                        .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                        .textTypeface(Typeface.DEFAULT_BOLD)
        );
    }

    public void setPlusMoney(int val) {
        String moneyText = mEditMoney.getText().toString();
        int money = 0;
        try {
            if( !StringUtils.isEmpty(moneyText) ) {
                money = Integer.parseInt(moneyText);
            }
        } catch (Exception e) {
            Logger.e("Exception : " + e);
        }
        mEditMoney.setText((money + val) + "");
        mEditMoney.setSelection(mEditMoney.getText().toString().length());
    }
}
