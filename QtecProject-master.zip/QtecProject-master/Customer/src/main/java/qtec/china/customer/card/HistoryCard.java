package qtec.china.customer.card;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.orhanobut.logger.Logger;
import it.gmariotti.cardslib.library.Constants;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import qtec.china.customer.DetailActivity;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.fragment.NoticeDetailFragment;
import qtec.china.customer.model.ModelHistory;

public class HistoryCard extends Card implements Card.OnCardClickListener {
    private BaseActivity mActivity;
    public ModelHistory.History mItem;
    public HistoryCard(BaseActivity activity, ModelHistory.History item) {
        super(activity, R.layout.card_inner_history);
        this.mActivity = activity;
        this.mItem = item;
        init();
    }

    private void init() {
        HistoryHeaderCard header = new HistoryHeaderCard(mActivity);
        header.setOtherButtonVisible(true);
        header.setOtherButtonClickListener(new CardHeader.OnClickCardHeaderOtherButtonListener() {
            @Override
            public void onButtonItemClick(Card card, View view) {
                mActivity.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + mItem.call)));
            }
        });
        header.setOtherButtonDrawable(R.drawable.ic_local_phone_grey600_24dp);
        addCardHeader(header);

        setOnClickListener(this);
    }

    @Override
    public void setupInnerViewElements(ViewGroup parent, View view) {
        TextView start = (TextView)view.findViewById(R.id.card_start);
        if( start != null ) {
            String text = mActivity.getString(R.string.history_start_title) + " " + mItem.start;
            int color = mActivity.getResources().getColor(R.color.history_start_title);
            final SpannableStringBuilder sp = new SpannableStringBuilder(text);
            sp.setSpan(new ForegroundColorSpan(color), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            start.setText(sp);
        }

        TextView end = (TextView)view.findViewById(R.id.card_end);
        if( end != null ) {
            String text = mActivity.getString(R.string.history_end_title) + " " + mItem.end;
            int color = mActivity.getResources().getColor(R.color.history_end_title);
            final SpannableStringBuilder sp = new SpannableStringBuilder(text);
            sp.setSpan(new ForegroundColorSpan(color), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            end.setText(sp);
        }

        TextView cost = (TextView)view.findViewById(R.id.card_cost);
        if( cost != null ) {
            cost.setText(mItem.cost + " " + mItem.payment);
        }

        TextView date = (TextView)view.findViewById(R.id.card_date);
        if( date != null ) {
            date.setText(mItem.date);
        }
    }

    @Override
    public void onClick(Card card, View view) {
        Intent intent = new Intent(mActivity, DetailActivity.class);
        intent.putExtra("id", mItem.id);
        mActivity.startActivity(intent);
    }

    public class HistoryHeaderCard extends CardHeader {

        public HistoryHeaderCard(Context context) {
            super(context, R.layout.card_header_inner_history);
        }

        @Override
        public void setupInnerViewElements(ViewGroup parent, View view) {
            if (view != null) {
                TextView t1 = (TextView) view.findViewById(R.id.title1);
                if( t1 != null ) {
                    t1.setText(mItem.name + " " + mItem.num);
                }

                TextView t2 = (TextView) view.findViewById(R.id.title2);
                if( t2 != null ) {
                    int color = Color.BLACK;
                    try {
                        color = Color.parseColor(mItem.color);
                    } catch (Exception e) {
                        Logger.e("setupInnerViewElements Error : " + e);
                    }
                    t2.setText(mItem.state);
                    t2.setTextColor(color);
                }
            }
        }
    }

}
