package qtec.china.customer.card;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.orhanobut.logger.Logger;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardHeader;
import it.gmariotti.cardslib.library.prototypes.CardWithList;
import qtec.china.customer.R;
import qtec.china.customer.model.ModelMileage;

import java.util.ArrayList;
import java.util.List;

public class MileageCard extends CardWithList {
    private ModelMileage mItem;
    public MileageCard(Context context, ModelMileage item) {
        super(context);
        mItem = item;
    }

    @Override
    protected CardHeader initCardHeader() {
        CardHeader header = new CardHeader(getContext(), R.layout.card_header_inner_mileage) {
            @Override
            public void setupInnerViewElements(ViewGroup parent, View view) {
                super.setupInnerViewElements(parent, view);
                TextView title = (TextView) view.findViewById(R.id.card_header_inner_title);
                TextView subTitle = (TextView) view.findViewById(R.id.card_header_inner_subtitle);
                if( title != null ) title.setText(R.string.title_activity_mileage);
                if( subTitle != null ) subTitle.setText(mItem.total);
            }
        };
        // header.setTitle(mService.title);
        return header;
    }

    @Override
    protected void initCard() { }

    @Override
    protected List<ListObject> initChildren() {
        List<ListObject> mObjects = new ArrayList<>();
        for( ModelMileage.Mileage item : mItem.getList() ) {
            mObjects.add(new MileageObject(this, item));
        }
        return mObjects;
    }

    public class MileageObject extends DefaultListObject {
        public ModelMileage.Mileage mMileage;
        public MileageObject(Card parentCard, ModelMileage.Mileage mileage) {
            super(parentCard);
            mMileage = mileage;
        }
    }

    @Override
    public int getChildLayoutId() { return R.layout.card_main_inner_mileage; }

    @Override
    public View setupChildView(int i, ListObject listObject, View view, ViewGroup viewGroup) {
        TextView data1 = (TextView) view.findViewById(R.id.txt_data1);
        TextView data2 = (TextView) view.findViewById(R.id.txt_data2);
        TextView data3 = (TextView) view.findViewById(R.id.txt_data3);
        if( listObject instanceof MileageObject ) {
            ModelMileage.Mileage mileage = ((MileageObject)listObject).mMileage;
            int color = Color.BLACK;
            try {
                color = Color.parseColor(mileage.color);
            } catch (Exception e) {
                Logger.e("setupChildView Error : " + e);
            }

            if( data1 != null ) {
                data1.setText(mileage.data1);
                // data1.setTextColor(color);
            }
            if( data2 != null ) {
                data2.setText(mileage.data2);
                data2.setTextColor(color);
            }
            if( data3 != null ) {
                data3.setText(mileage.data3);
                data3.setTextColor(color);
            }
        }
        return view;
    }
}
