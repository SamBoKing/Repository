package qtec.china.customer.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.ImageView;
import android.widget.TextView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.orhanobut.logger.Logger;
import qtec.china.customer.R;
import qtec.china.customer.RecommendActivity;
import qtec.china.customer.base.BaseFragment;
import qtec.china.customer.object.RecommendItem;

import java.io.DataInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

public class RecommendFragment extends BaseFragment {
    private RecommendActivity mParent;
    private RecommendItem mItem;
    private Intent mShareIntent;
    public static RecommendFragment newInstance(RecommendActivity activity, RecommendItem item) {
        RecommendFragment fr = new RecommendFragment();
        fr.setArguments(activity, item);
        return fr;
    }

    private void setArguments(RecommendActivity activity, RecommendItem item) {
        this.mParent = activity;
        this.mItem = item;
    }

    public String getTitle() {
        return mItem.title;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_recommend, container, false);
        initView(rootView);
        return rootView;
    }

    private void initView(View root) {
        ImageView img = (ImageView)root.findViewById(R.id.img_qrcode);
        img.setImageResource(mItem.qrcode);

        TextView link = (TextView)root.findViewById(R.id.txt_link);
        link.setText(mItem.link);
    }

    private Intent defaulShareIntent() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        try {
            intent.putExtra(Intent.EXTRA_SUBJECT, mItem.title);
            intent.putExtra(Intent.EXTRA_TEXT, mItem.link);

            Uri uri = getQRImage();
            if( uri == null ) {
                uri = inertQRImage();
            }
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
        } catch(Exception e) {
            Logger.e("defaulShareIntent : " +  e.getMessage());
        }
        return intent;
    }

    private Uri inertQRImage() {
        Uri uri = Uri.parse(MediaStore.Images.Media.insertImage(mParent.getContentResolver(),
                BitmapFactory.decodeResource(mParent.getResources(), mItem.qrcode), mItem.title, null));
        mParent.mSetting.setQRCode(mItem.key, uri.toString());
        return uri;
    }

    public Uri getQRImage() {
        String qrUri = mParent.mSetting.getQRCode(mItem.key);
        if( !StringUtils.isEmpty(qrUri) ) {
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(mParent.getContentResolver(), Uri.parse(qrUri));
                if( bitmap != null ) {
                    return Uri.parse(qrUri);
                }
            } catch (Exception ex) {
                Logger.e("getQRImage : " + qrUri + "\nError : " + ex);
            }
        }
        return null;
    }


    @Override
    public void setMenuVisibility(boolean menuVisible) {
        if( menuVisible ) {
            if (mShareIntent == null) {
                mShareIntent = defaulShareIntent();
            }
            mParent.setShearIntent(mShareIntent);
        }
    }


}
