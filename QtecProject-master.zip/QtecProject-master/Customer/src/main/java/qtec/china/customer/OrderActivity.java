package qtec.china.customer;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.gc.materialdesign.views.ButtonRectangle;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.Volleyer;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.orhanobut.logger.Logger;
import com.quinny898.library.persistentsearch.SearchBox;
import com.quinny898.library.persistentsearch.SearchResult;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.model.ModelOrder;
import qtec.china.customer.model.ModelSearch;
import qtec.china.customer.model.ModelSearch.Search;

import java.util.ArrayList;
import java.util.List;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;


public class OrderActivity extends BaseActivity implements View.OnClickListener {

    private SearchBox mSearch;
    private EditText mEditCount;
    private TextView mTextPhone;
    private String mTempPhone;
    private TextView mTextLocation;
    private RadioGroup mRadioPayment;
    private ButtonRectangle mBtnOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        initToolbar();
        initSearchBox();
        initView();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.layout_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mSearch.isShown()) {
                    closeSearchBox();
                } else {
                    finish();
                }
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initSearchBox() {
        mSearch = (SearchBox)findViewById(R.id.searchbox);
        mSearch.enableVoice(this);
        mSearch.setItemBackground(R.drawable.selector_search_item);
        mSearch.setMenuListener(new SearchBox.MenuListener() {
            @Override
            public void onMenuClick() {
                closeSearchBox();
            }
        });

        mSearch.setResultListener(new SearchBox.ResultListener() {
            @Override
            public void onResultClick(SearchResult result) {
                closeSearchBox();
                if (result.obj instanceof Search) {
                    Search search = (Search) result.obj;
                    mTextLocation.setText(search.title);
                }
            }
        });

        mSearch.setSearchListener(new SearchBox.SearchListener() {
            @Override
            public void onSearchOpened() {
            }

            @Override
            public void onSearchCleared() { }

            @Override
            public void onSearchClosed() { }

            @Override
            public void onSearchTermChanged() {
            }

            @Override
            public void onSearch(final String s) {
                mSearch.showLoading(true);
                volleyer().get(makeUrl(Page.getSearch))
                        .addHeader("search", s)
                        .withErrorListener(OrderActivity.this)
                        .withListener(new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                mSearch.showLoading(false);
                                mData.Search = new Gson().fromJson(response, ModelSearch.class);

                                // TODO : Test Logic
                                if (s.equals("bbb")) {
                                    mData.Search.clearList();
                                } else {
                                    mData.Search.updateList(s);
                                }
                                drawModelSearch();
                            }
                        })
                        .execute();
            }
        });
    }

    private void initView() {
        // mPhone = mData.User.phone;
        mTextPhone = (TextView) findViewById(R.id.text_phone);
        mTextPhone.setText("010-9395-9999");

        mTextLocation = (TextView) findViewById(R.id.text_location);
        mTextLocation.setText("대구광역시 북구 칠성2가");

        mEditCount = (EditText) findViewById(R.id.edit_count);
        mEditCount.setText("1");

        mRadioPayment = (RadioGroup) findViewById(R.id.radio_group_payment);
        mBtnOrder = (ButtonRectangle)findViewById(R.id.button_order);
        mBtnOrder.setRippleSpeed(500);
        mBtnOrder.setOnClickListener(this);

        findViewById(R.id.layout_map).setOnClickListener(this);
        findViewById(R.id.layout_phone).setOnClickListener(this);
        findViewById(R.id.button_plus).setOnClickListener(this);
        findViewById(R.id.button_minus).setOnClickListener(this);


        RadioButton payment1 = (RadioButton)findViewById(R.id.radio_payment1);
        // payment1.setEnabled(mData.User.payment1);
        payment1.setEnabled(true);
        RadioButton payment2 = (RadioButton)findViewById(R.id.radio_payment2);
        payment2.setEnabled(mData.User.payment2);
        RadioButton payment3 = (RadioButton)findViewById(R.id.radio_payment3);
        payment3.setEnabled(mData.User.payment3);
    }

    private void drawModelSearch() {
        List<SearchResult> results = new ArrayList<>();
        for(Search item : mData.Search.getList()) {
            results.add(new SearchResult(item.title,
                    getResources().getDrawable(R.drawable.ic_search_grey600_48dp),
                    item));
        }
        mSearch.updateResults(results);
    }

    private void showSearchBox() {
        mSearch.revealFromMenuItem(R.id.action_search, this);
    }

    private void closeSearchBox() {
        mSearch.hideCircularly(this);
    }

    @Override
    public void onBackPressed() {
        if( mSearch.isShown() ) {
            closeSearchBox();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SearchBox.VOICE_RECOGNITION_CODE && resultCode == RESULT_OK) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            mSearch.populateEditText(matches);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_order, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case R.id.action_search:
                showSearchBox();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch ( view.getId() ) {
            case R.id.layout_map:
                if( !mSearch.isShown() ) {
                    showSearchBox();
                }
                break;
            case R.id.layout_phone:
                showPhoneDialog();
                break;
            case R.id.button_plus:
                setEditCount(1);
                break;
            case R.id.button_minus:
                setEditCount(-1);
                break;
            case R.id.button_order:
                requestModelOrder();
                break;
        }
    }

    private void requestModelOrder() {
        int payment_id = mRadioPayment.getCheckedRadioButtonId();
        if( payment_id == -1 ) {
            showError(R.string.order_fail_payment);
            return;
        }

        String payment_type = "";
        switch ( payment_id ) {
            case R.id.radio_payment1: payment_type = "1"; break;
            case R.id.radio_payment2: payment_type = "2"; break;
            case R.id.radio_payment3: payment_type = "3"; break;
        }

        displayLoading(true);
        Volleyer.volleyer().get(makeUrl(Page.getOrder))
                .addHeader("id", mData.User.id)
                .addHeader("phone", mTextPhone.getText().toString())
                .addHeader("count", mEditCount.getText().toString())
                .addHeader("payment", payment_type)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        final ModelOrder order = new Gson().fromJson(response, ModelOrder.class);
                        new MaterialDialog.Builder(OrderActivity.this)
                                .content(order.message)
                                .positiveText(R.string.ok)
                                .cancelable(false)
                                .callback(new MaterialDialog.ButtonCallback() {
                                    @Override
                                    public void onPositive(MaterialDialog dialog) {
                                        if (order.success) {
                                            startActivity(new Intent(OrderActivity.this, HistoryActivity.class));
                                            finish();
                                        }
                                    }
                                })
                                .show();
                    }
                }).execute();
    }

    private void setEditCount(int val) {
        String countText = mEditCount.getText().toString();
        int count = 0;
        try {
            if( !StringUtils.isEmpty(countText) ) {
                count = Integer.parseInt(countText);
            }
        } catch (Exception e) {
            Logger.e("Exception : " + e);
        }

        int result = count + val;
        if( result < 1 || result > 9 ) {
            return;
        }
        mEditCount.setText(result + "");
    }

    private void showPhoneDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.order_edit_phone_title)
                .content(R.string.order_edit_phone_subtitle)
                .inputType(InputType.TYPE_CLASS_PHONE)
                .positiveText(R.string.save)
                .negativeText(R.string.close)
                .alwaysCallInputCallback()
                .input(getString(R.string.order_edit_phone_hint), mTextPhone.getText().toString(), false, new MaterialDialog.InputCallback() {
                    @Override
                    public void onInput(MaterialDialog dialog, CharSequence input) {
                        mTempPhone = input.toString();
                        dialog.getActionButton(DialogAction.POSITIVE).setEnabled(input.length() > 0);
                    }
                })
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        mTextPhone.setText(mTempPhone);
                    }
                })
                .show();
    }

    public void showError(int textRes) {
        SnackbarManager.show(
                Snackbar.with(this)
                        .colorResource(R.color.md_deep_orange_500)
                        .textColorResource(R.color.textColorPrimary)
                        .text(textRes)
                        .margin(Common.getDimension(this, 20))
                        .position(Snackbar.SnackbarPosition.TOP)
                        .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                        .textTypeface(Typeface.DEFAULT_BOLD)
        );
    }
}
