package qtec.china.customer.card;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.SupportMapFragment;
import com.baidu.mapapi.model.LatLng;
import com.gc.materialdesign.views.ButtonFloatSmall;
import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.orhanobut.logger.Logger;
import com.squareup.picasso.Picasso;
import it.gmariotti.cardslib.library.internal.*;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.fragment.BaiduMapFragment;
import qtec.china.customer.fragment.DetailMapFragment;
import qtec.china.customer.fragment.NoticeFragment;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.model.ModelCancel;
import qtec.china.customer.model.ModelDetail;
import qtec.china.customer.model.ModelRating;
import qtec.china.customer.model.ModelResult;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;
import static qtec.china.customer.helper.UrlHelper.makeUrl;

public class DetailRiderCard extends Card {
    private BaseActivity mActivity;
    private ModelDetail mDetail;
    private DetailMapFragment mBaiduMap;
    public DetailRiderCard(BaseActivity activity, ModelDetail detail) {
        super(activity, R.layout.card_inner_detail_rider);
        this.mActivity = activity;
        this.mDetail = detail;
        init();
    }

    public void init() {
        DetailRiderHeader header = new DetailRiderHeader(getContext());
        header.setButtonOverflowVisible(true);
        addCardHeader(header);

        DetailRiderExpand expand = new DetailRiderExpand(getContext());
        addCardExpand(expand);

        DetailRiderThumb thumbnail = new DetailRiderThumb(getContext());
        thumbnail.setUrlResource(mDetail.url);
        thumbnail.setErrorResource(R.drawable.empty_profile2);
        addCardThumbnail(thumbnail);
    }

    @Override
    public void setupInnerViewElements(ViewGroup parent, View view) {
        RatingBar ration = (RatingBar) view.findViewById(R.id.rating);
        TextView data1 = (TextView) view.findViewById(R.id.data1);
        TextView data2 = (TextView) view.findViewById(R.id.data2);
        TextView data3 = (TextView) view.findViewById(R.id.data3);
        TextView data4 = (TextView) view.findViewById(R.id.data4);
        TextView data5 = (TextView) view.findViewById(R.id.data5);
        TextView data6 = (TextView) view.findViewById(R.id.data6);
        TextView data7 = (TextView) view.findViewById(R.id.data7);
        TextView data8 = (TextView) view.findViewById(R.id.data8);
        ration.setRating(mDetail.rating);
        data1.setText(mDetail.data1);
        data2.setText(mDetail.data2);
        data3.setText(mDetail.data3);
        data4.setText(mDetail.data4);
        data5.setText(mDetail.data5);
        data6.setText(mDetail.data6);
        data7.setText(mDetail.data7);
        data8.setText(mDetail.data8);
    }

    public void  showRatingDialog() {
        new MaterialDialog.Builder(mActivity)
                .title(R.string.detail_rider_rating_dialog_title)
                .customView(R.layout.dialog_detail_rating, true)
                .positiveText(R.string.save)
                .negativeText(R.string.close)
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        View view = dialog.getCustomView();
                        RatingBar rating = (RatingBar) view.findViewById(R.id.rating);
                        if (rating != null) {
                            requestModelRating((int)rating.getRating());
                        } else {
                            Logger.e("Not found ratingbar!");
                        }
                    }
                }).show();
    }

    private void requestModelRating(int rating) {
        mActivity.displayLoading(true);
        volleyer().get(makeUrl(Page.getRating))
                .addHeader("id", mActivity.mData.Detail.rid)
                .addHeader("rating", rating + "")
                .withErrorListener(mActivity)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mActivity.displayLoading(false);
                        ModelRating result = new Gson().fromJson(response, ModelRating.class);
                        new MaterialDialog.Builder(mActivity)
                                .content(result.message)
                                .positiveText(R.string.ok)
                                .show();
                    }
                })
                .execute();
    }

    class DetailRiderHeader extends CardHeader {
        public DetailRiderHeader(Context context) {
            super(context, R.layout.card_header_inner_detail_rider);
        }

        @Override
        public void setupInnerViewElements(ViewGroup parent, View view) {
            super.setupInnerViewElements(parent, view);
            ButtonFloatSmall img_map = (ButtonFloatSmall) view.findViewById(R.id.img_map);
            ButtonFloatSmall img_rating = (ButtonFloatSmall) view.findViewById(R.id.img_rating);
            ButtonFloatSmall img_call = (ButtonFloatSmall) view.findViewById(R.id.img_call);

            ViewToClickToExpand viewToClickToExpand = ViewToClickToExpand.builder().setupView(img_map);
            setViewToClickToExpand(viewToClickToExpand);

            img_rating.setVisibility(mDetail.is_rating ? View.VISIBLE : View.GONE);
            img_rating.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showRatingDialog();
                }
            });
            img_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getContext().startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + mDetail.call)));
                }
            });
        }
    }

    class DetailRiderExpand extends CardExpand {
        public DetailRiderExpand(Context context) {
            super(context, R.layout.fragment_detail_map);
        }

        @Override
        public void setupInnerViewElements(ViewGroup parent, View view) {
            mBaiduMap = DetailMapFragment.newInstance(mActivity);
            mActivity.getSupportFragmentManager().beginTransaction()
                    .replace(R.id.map, mBaiduMap).commit();
        }
    }

    class DetailRiderThumb extends CardThumbnail {
        public DetailRiderThumb(Context context) {
            super(context);
        }

        @Override
        public void setupInnerViewElements(ViewGroup parent, View viewImage) {
            if (viewImage != null) {
                if (parent != null && parent.getResources() != null){
                    DisplayMetrics metrics = parent.getResources().getDisplayMetrics();
                    int w = 90;
                    int h = 110;
                    if( metrics != null ){
                        viewImage.getLayoutParams().width = (int)(w*metrics.density);
                        viewImage.getLayoutParams().height = (int)(h*metrics.density);
                    } else {
                        viewImage.getLayoutParams().width = w;
                        viewImage.getLayoutParams().height = h;
                    }
                    // viewImage.setBackgroundResource(R.drawable.shape_detail_rider);
                    FrameLayout.LayoutParams params = (FrameLayout.LayoutParams)viewImage.getLayoutParams();
                    params.setMargins(10, 0, 0, 0);
                    viewImage.setLayoutParams(params);
                }
            }
        }
    }
}
