package qtec.china.customer.adapter;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import qtec.china.customer.RecommendActivity;
import qtec.china.customer.fragment.RecommendFragment;
import qtec.china.customer.object.RecommendItem;

import java.util.ArrayList;
import java.util.List;

public class RecommendPagerAdapter extends FragmentStatePagerAdapter {
    List<RecommendFragment> _list =  new ArrayList<>();
    public RecommendPagerAdapter(RecommendActivity activity, FragmentManager fm, RecommendItem[] items) {
        super(fm);
        for(RecommendItem item : items) {
            _list.add(RecommendFragment.newInstance(activity, item));
        }
    }

    @Override
    public RecommendFragment getItem(int i) {return _list.get(i); }

    @Override
    public int getCount() { return _list.size(); }

    @Override
    public CharSequence getPageTitle(int i) { return getItem(i).getTitle(); }
}
