package qtec.china.customer.base;

import com.baidu.mapapi.map.BaiduMapOptions;
import com.baidu.mapapi.map.SupportMapFragment;
import com.orhanobut.logger.Logger;

import java.lang.reflect.Field;

public class BaseBaiduMapFragment extends SupportMapFragment {
    public void setMapOptions(BaiduMapOptions baiduMapOptions) {
        if( baiduMapOptions == null ) {
            return;
        }

        try {
            Class<?> doc = this.getClass().getSuperclass().getSuperclass();
            Field field = doc.getDeclaredField("c");    // BaiduMapOptions Filed
            field.setAccessible(true);
            field.set(this, baiduMapOptions);
            field.setAccessible(false);
        } catch (final Throwable ignored) {
            Logger.e("BaiduMapFragment set BaiduMapOptions is failed");
        }
    }
}
