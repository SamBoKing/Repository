package qtec.china.customer.baidumap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MarkerOptions;
import qtec.china.customer.baidumap.library.clustering.Cluster;
import qtec.china.customer.baidumap.library.clustering.ClusterManager;
import qtec.china.customer.baidumap.library.clustering.view.DefaultClusterRenderer;
import qtec.china.customer.R;
import qtec.china.customer.common.Common;
import qtec.china.customer.drawable.MultiDrawable;
import qtec.china.customer.googlemap.RiderIconGenerator;

import java.util.ArrayList;
import java.util.List;

import static qtec.china.customer.model.ModelRider.Rider;

public class RiderClusterRenderer extends DefaultClusterRenderer<Rider> {
    private RiderIconGenerator clusterIconGenerator;
    private ImageView clusterImageView;
    private RiderIconGenerator itemIconGenerator;
    private ImageView itemimageView;
    private TextView itemTextView;
    private RatingBar itemRatingBar;

    private Context context;
    private Drawable defaultDrawable;
    private int dimensionWidth;
    private int dimensionHeight;

    public RiderClusterRenderer(Context context, BaiduMap map, ClusterManager<Rider> clusterManager) {
        super(context, map, clusterManager);
        this.context = context;

        dimensionWidth = (int) context.getResources().getDimension(R.dimen.marker_width);
        dimensionHeight = (int) context.getResources().getDimension(R.dimen.marker_height);

        defaultDrawable = Common.getDrawableWithColorFilter(context, R.drawable.ic_portrait_white_48dp, Color.GRAY);
        defaultDrawable.setBounds(0, 0, dimensionWidth, dimensionHeight);

        // Cluster Layout
        clusterIconGenerator = new RiderIconGenerator(context);
        View clusterView = LayoutInflater.from(context).inflate(R.layout.map_cluster_view, null);
        clusterIconGenerator.setContentView(clusterView);
        clusterImageView = (ImageView) clusterView.findViewById(R.id.image);
        clusterImageView.setImageDrawable(defaultDrawable);

        // Cluster Item Layout
        itemIconGenerator = new RiderIconGenerator(context);
        View itemView = LayoutInflater.from(context).inflate(R.layout.map_cluster_item, null);
        itemIconGenerator.setContentView(itemView);
        itemimageView = (ImageView) itemView.findViewById(R.id.image);
        itemTextView = (TextView) itemView.findViewById(R.id.name);
        itemRatingBar = (RatingBar) itemView.findViewById(R.id.rating);
        itemimageView.setImageDrawable(defaultDrawable);
    }

    @Override
    protected void onBeforeClusterItemRendered(Rider item, MarkerOptions markerOptions) {
        if( item.bitmap == null ) {
            itemimageView.setImageDrawable(defaultDrawable);
        } else {
            itemimageView.setImageBitmap(item.bitmap);
        }
        itemTextView.setText(item.name);
        itemRatingBar.setRating(item.rating);

        Bitmap icon = itemIconGenerator.makeIcon();
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(icon));
    }

    @Override
    protected void onBeforeClusterRendered(Cluster<Rider> cluster, MarkerOptions markerOptions) {
        List<Drawable> profilePhotos = new ArrayList<>(Math.min(4, cluster.getSize()));
        for (Rider r : cluster.getItems()) {
            if (profilePhotos.size() == 4) break;

            Drawable drawable = ( r.bitmap == null ) ? defaultDrawable : bitmapToDrawable(r.bitmap);
            profilePhotos.add(drawable);
        }
        MultiDrawable multiDrawable = new MultiDrawable(profilePhotos);
        multiDrawable.setBounds(0, 0, dimensionWidth, dimensionHeight);
        clusterImageView.setImageDrawable(multiDrawable);

        Bitmap icon = clusterIconGenerator.makeIcon(String.valueOf(cluster.getSize()));
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(icon));
    }

    @Override
    protected boolean shouldRenderAsCluster(Cluster cluster) {
        return cluster.getSize() > 1;
    }

    public Drawable bitmapToDrawable(Bitmap bitmap) {
        Drawable d = new BitmapDrawable(context.getResources(), bitmap);
        d.setBounds(0, 0, dimensionWidth, dimensionHeight);
        return d;
    }
}
