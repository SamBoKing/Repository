package qtec.china.customer.model;

public class ModelCancel {
    public boolean success;
    public String message;
}
