package qtec.china.customer.model;

public class ModelUser {
    public String id = "";
    public String name;
    public String level;
    public String phone;
    public String img;
    public int mileage;
    public boolean payment1;
    public boolean payment2;
    public boolean payment3;
    public boolean is_login;
    public boolean is_menu;
    public boolean is_order;
    public boolean is_notice;
    public boolean is_update;
}
