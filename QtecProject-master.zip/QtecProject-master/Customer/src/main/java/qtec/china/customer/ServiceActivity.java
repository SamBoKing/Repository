package qtec.china.customer;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.*;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.readystatesoftware.systembartint.SystemBarTintManager;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardGridArrayAdapter;
import it.gmariotti.cardslib.library.view.CardGridView;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.card.ServiceCard;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.model.ModelPrice;
import qtec.china.customer.model.ModelService;

import java.util.ArrayList;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;
import static qtec.china.customer.helper.UrlHelper.makeUrl;


public class ServiceActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            w.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);
        initStateBar();
        initToolbar();

        if( mData.Service.is_load ) {
            drawModelService();
        } else {
            requestModelService();
        }
    }

    private void initStateBar() {
        SystemBarTintManager sbt = new SystemBarTintManager(this);
        sbt.setStatusBarTintEnabled(true);
        sbt.setNavigationBarTintEnabled(true);
        sbt.setStatusBarAlpha(0.0f);
        sbt.setNavigationBarAlpha(1.0f);
        // sbt.setStatusBarTintResource(R.color.appThemeColorDark);
        sbt.setNavigationBarTintResource(R.color.appThemeColor);
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setBackgroundColor(Color.TRANSPARENT);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void requestModelService() {
        displayLoading(true);
        volleyer().get(makeUrl(Page.getService))
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        mData.Service = new Gson().fromJson(response, ModelService.class);
                        mData.Service.is_load = true;
                        drawModelService();
                    }
                })
                .execute();
    }

    private void drawModelService() {
        ArrayList<Card> cards = new ArrayList<>();
        for (ModelService.Service item : mData.Service.getList() ) {
            ServiceCard card = new ServiceCard(this, item);
            card.init();
            cards.add(card);
        }

        CardGridArrayAdapter mCardArrayAdapter = new CardGridArrayAdapter(this, cards);
        CardGridView listView = (CardGridView) findViewById(R.id.card_grid);
        if (listView != null) {
            listView.setAdapter(mCardArrayAdapter);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_service, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch( item.getItemId() ) {
            case R.id.action_service:
                new MaterialDialog.Builder(this)
                        .title(R.string.title_activity_service)
                        .content(R.string.title_activity_service)
                        .positiveText(R.string.ok)
                        .show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
