package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelHistory {
    public static class History {
        public String id;
        public String name;
        public String num;
        public String state;
        public String color;
        public String call;
        public String start;
        public String end;
        public String cost;
        public String payment;
        public String date;
    }

    public boolean is_update;
    List<History> list = new ArrayList<>();
    public List<History> getList() {
        return list;
    }
}
