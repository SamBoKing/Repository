package qtec.china.customer.base;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.inputmethod.InputMethodManager;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import qtec.china.customer.R;
import qtec.china.customer.manager.DataManager;
import qtec.china.customer.manager.SettingManager;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class BaseActivity extends AppCompatActivity implements Response.ErrorListener {
    private InputMethodManager mInputMgr;
    private MaterialDialog mLoading;
    public DataManager mData;
    public SettingManager mSetting;
    private boolean isExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MenuKeyInterceptor.intercept(this);

        mData = DataManager.getInstance();
        mSetting = SettingManager.getInstance(this);
        mInputMgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    public void displayLoading(boolean show) {
        if( mLoading == null ) {
            mLoading = new MaterialDialog.Builder(this)
                    .content(R.string.please_wait)
                    .progress(true, 0).build();
        }

        if( show ) {
            mLoading.show();
        } else {
            mLoading.dismiss();
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        displayLoading(false);
        new MaterialDialog.Builder(this)
                .content(R.string.failed_network_connect)
                .positiveText(R.string.ok)
                .show();
    }

    protected void showExit() {
        new MaterialDialog.Builder(this)
                .title(R.string.app_exit_title)
                .content(R.string.app_exit_message)
                .negativeText(R.string.cancel)
                .positiveText(R.string.ok)
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        super.onPositive(dialog);
                        isExit = true;
                        finish();
                    }
                })
                .show();
    }

    public void showCall() {
        String call = StringUtils.isEmpty(mData.Config.call) ? getString(R.string.call_number) : mData.Config.call;
        startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + call)));
    }

    public void showEmail() {
        String email = StringUtils.isEmpty(mData.Config.email) ? getString(R.string.email_address) : mData.Config.email;
        String title = getString(R.string.email_title);
        String body =   "======================\n" +
                        "Device : " + Build.MODEL + "\n" +
                        "Android : " + Build.VERSION.RELEASE + "\n" +
                        "======================\n\n";

        Intent it = new Intent(Intent.ACTION_SENDTO, Uri.parse(("mailto:" + email) + "?subject=" + title + "&body=" + Uri.encode(body)));
        startActivity(it);
    }

    public void hideKeyboard() {
        if( getCurrentFocus() != null ) {
            mInputMgr.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    // Custom Font Default Config
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onDestroy() {
        if( isExit ) {
            DataManager.release();
            SettingManager.release();
        }
        super.onDestroy();
    }
}
