package qtec.china.customer.card;

import android.support.annotation.UiThread;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.internal.Card;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.fragment.AgreementFragment;
import qtec.china.customer.fragment.CompanyInfoFragment;
import qtec.china.customer.object.EtceteraItem;

public class EtceteraCard extends Card implements Card.OnCardClickListener  {
    private BaseActivity mActivity;
    private EtceteraItem item;
    public EtceteraCard(BaseActivity activity, EtceteraItem item) {
        super(activity, R.layout.card_inner_etcetera);
        this.mActivity = activity;
        this.item = item;
        init();
    }

    private void init() {
        setOnClickListener(this);
    }

    @Override
    public void setupInnerViewElements(ViewGroup parent, View view) {
        ImageView icon = (ImageView)view.findViewById(R.id.card_icon);
        TextView title = (TextView)view.findViewById(R.id.card_title);
        TextView subtitle = (TextView)view.findViewById(R.id.card_subtitle);
        ImageView arrow = (ImageView)view.findViewById(R.id.card_arrow);
        icon.setImageResource(item.icon);
        title.setText(item.title);
        subtitle.setText(item.subtitle);
        switch( getId() ) {
            case "2":
                if( !StringUtils.isEmpty(mActivity.mData.Config.call) )
                    subtitle.setText(mActivity.mData.Config.call);
                break;
            case "3":
                if( !StringUtils.isEmpty(mActivity.mData.Config.email) )
                    subtitle.setText(mActivity.mData.Config.email);
                break;
        }
        arrow.setVisibility(item.arrow ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onClick(Card card, View view) {
        switch( card.getId() ) {
            case "0":
                mActivity.getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, R.anim.slide_in_left, R.anim.slide_out_right)
                        .addToBackStack(null)
                        .replace(R.id.container, new AgreementFragment())
                        .commit();
                break;
            case "1":
                mActivity.getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, R.anim.slide_in_left, R.anim.slide_out_right)
                        .addToBackStack(null)
                        .replace(R.id.container, new CompanyInfoFragment())
                        .commit();

                break;
            case "2":
                mActivity.showCall();
                break;
            case "3":
                mActivity.showEmail();
                break;
        }
    }
}