package qtec.china.customer.object;

public class EtceteraItem {
    public int icon;
    public int title;
    public int subtitle;
    public boolean arrow;
    public EtceteraItem(int icon, int title, int subtitle, boolean arrow) {
        this.icon = icon;
        this.title = title;
        this.subtitle = subtitle;
        this.arrow = arrow;
    }
}
