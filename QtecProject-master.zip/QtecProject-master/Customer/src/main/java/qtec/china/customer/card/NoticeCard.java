package qtec.china.customer.card;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import it.gmariotti.cardslib.library.internal.Card;
import qtec.china.customer.R;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.common.Common;
import qtec.china.customer.fragment.NoticeDetailFragment;
import qtec.china.customer.model.ModelNotice;

public class NoticeCard extends Card implements Card.OnCardClickListener  {
    private BaseActivity mActivity;
    private ModelNotice.Notice item;
    public NoticeCard(BaseActivity activity, ModelNotice.Notice item) {
        super(activity, R.layout.card_inner_notice);
        this.mActivity = activity;
        this.item = item;
        init();
    }

    private void init() {
        setOnClickListener(this);
    }

    @Override
    public void setupInnerViewElements(ViewGroup parent, View view) {
        int iconRes = item.read ? R.drawable.ic_drafts_white_48dp : R.drawable.ic_mail_white_48dp;
        Drawable drawable = Common.getDrawableWithColorFilter(mActivity, iconRes, Color.parseColor("#FFDFAA50"));
        ImageView icon = (ImageView)view.findViewById(R.id.card_icon);
        TextView title = (TextView)view.findViewById(R.id.card_title);
        icon.setImageDrawable(drawable);
        title.setText(item.title);
    }

    @Override
    public void onClick(Card card, View view) {
        mActivity.getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, R.anim.slide_in_left, R.anim.slide_out_right)
                .addToBackStack(null)
                .replace(R.id.container, NoticeDetailFragment.newInstance(item))
                .commit();
    }
}