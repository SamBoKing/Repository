package qtec.china.customer;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import com.android.volley.Response;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import it.gmariotti.cardslib.library.view.CardViewNative;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.card.UserCard;
import qtec.china.customer.model.ModelUser;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;


public class UserActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        initToolbar();
        drawModelUser();

        // Todo Test
        if( StringUtils.isEmpty(mData.User.id) ) {
            requestModelUser();
        }
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void requestModelUser() {
        volleyer().get(makeUrl(Page.getUser))
                .addHeader("id", mSetting.getUserId())
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.User = new Gson().fromJson(response, ModelUser.class);
                        drawModelUser();
                    }
                })
                .execute();
    }

    private void drawModelUser() {
        UserCard card = new UserCard(this, mData.User);
        card.init();

        CardViewNative cardView = (CardViewNative) findViewById(R.id.card_user);
        cardView.setCard(card);
    }
}
