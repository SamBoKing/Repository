package qtec.china.customer;

import android.content.Intent;
import android.os.Bundle;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.navercorp.volleyextensions.volleyer.util.StringUtils;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.dialog.LoginDialog;
import qtec.china.customer.helper.UrlHelper;
import qtec.china.customer.helper.UrlHelper.Page;
import qtec.china.customer.model.ModelConfig;
import qtec.china.customer.model.ModelUser;

import java.util.Calendar;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;

public class IntroActivity extends BaseActivity {
    private boolean isBackPressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        requestModelConfig();
    }

    private void requestModelConfig() {
        volleyer().get(UrlHelper.makeUrl(Page.getConfig))
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.Config = new Gson().fromJson(response, ModelConfig.class);
                        // if( StringUtils.isEmpty(mSetting.getUserId()) )
                        if( isLogin() )
                            onSuccess();
                        else
                            requestModelUser();
                    }
                })
                .execute();
    }

    private void requestModelUser() {
        volleyer().get(UrlHelper.makeUrl(Page.getUser))
                .addHeader("id", mSetting.getUserId())
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mData.User = new Gson().fromJson(response, ModelUser.class);
                        onSuccess();
                    }
                })
                .execute();
    }

    private void onSuccess() {
        Intent intent = new Intent(this, BaiduMapActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        isBackPressed = true;
        new MaterialDialog.Builder(this)
                .content(R.string.failed_network_connect)
                .negativeText(R.string.reconnect)
                .positiveText(R.string.exit)
                .callback(new MaterialDialog.ButtonCallback() {
                    @Override
                    public void onPositive(MaterialDialog dialog) {
                        finish();
                    }
                    @Override
                    public void onNegative(MaterialDialog dialog) {
                        requestModelConfig();
                    }
                })
                .show();
    }

    @Override
    public void onBackPressed() {
        if( isBackPressed ) {
            super.onBackPressed();
        }
    }

    // Todo Test
    private boolean isLogin() {
        return Calendar.getInstance().get(Calendar.MINUTE) % 2 == 0;
    }
}
