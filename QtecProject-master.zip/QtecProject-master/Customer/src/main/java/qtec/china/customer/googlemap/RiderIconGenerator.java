package qtec.china.customer.googlemap;

import android.content.Context;
import qtec.china.customer.baidumap.library.ui.IconGenerator;

public class RiderIconGenerator extends IconGenerator {
    public RiderIconGenerator(Context context) {
        super(context);
        this.setBackground(new RiderBubbleDrawable(context.getResources()));
    }
}
