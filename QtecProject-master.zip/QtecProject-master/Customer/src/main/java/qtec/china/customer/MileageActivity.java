package qtec.china.customer;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import com.android.volley.Response;
import com.google.gson.Gson;
import it.gmariotti.cardslib.library.view.CardViewNative;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.card.MileageCard;
import qtec.china.customer.model.ModelMileage;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.Page;
import static qtec.china.customer.helper.UrlHelper.makeUrl;


public class MileageActivity extends BaseActivity {

    private CardViewNative mCardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mileage);
        initToolbar();
        initView();
        requestModelMileage();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void initView() {
        mCardView = (CardViewNative) findViewById(R.id.card_mileage);
        mCardView.setVisibility(View.GONE);
    }

    private void requestModelMileage() {
        displayLoading(true);
        volleyer().get(makeUrl(Page.getMileage))
                .addHeader("id", mData.User.id)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        mData.Mileage = new Gson().fromJson(response, ModelMileage.class);
                        drawModelMileage();
                    }
                })
                .execute();
    }

    private void drawModelMileage() {
        MileageCard card = new MileageCard(this, mData.Mileage);
        card.init();

        mCardView.setCard(card);
        mCardView.setVisibility(View.VISIBLE);
    }
}
