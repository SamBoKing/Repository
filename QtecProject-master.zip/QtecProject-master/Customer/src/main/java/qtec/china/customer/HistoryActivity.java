package qtec.china.customer;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import com.android.volley.Response;
import com.google.gson.Gson;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.internal.CardArrayAdapter;
import it.gmariotti.cardslib.library.view.CardListView;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.card.HistoryCard;
import qtec.china.customer.model.ModelHistory;

import java.util.ArrayList;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.*;
import static qtec.china.customer.helper.UrlHelper.makeUrl;


public class HistoryActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        initToolbar();
        requestModelHistory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if( mData.History.is_update ) {
            requestModelHistory();
        }
    }

    private void requestModelHistory() {
        mData.History.is_update = false;
        displayLoading(true);
        volleyer().get(makeUrl(Page.getHistory))
                .addHeader("id", mData.User.id)
                .withErrorListener(this)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        displayLoading(false);
                        mData.History = new Gson().fromJson(response, ModelHistory.class);
                        drawModelHistory();
                    }
                })
                .execute();
    }

    private void drawModelHistory() {
        ArrayList<Card> cards = new ArrayList<>();
        for( ModelHistory.History item : mData.History.getList() ) {
            HistoryCard card = new HistoryCard(this, item);
            cards.add(card);
        }

        CardArrayAdapter mCardArrayAdapter = new CardArrayAdapter(this, cards);
        CardListView listView = (CardListView) findViewById(R.id.card_list);
        if( listView != null ){
            listView.setAdapter(mCardArrayAdapter);
        }
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
}
