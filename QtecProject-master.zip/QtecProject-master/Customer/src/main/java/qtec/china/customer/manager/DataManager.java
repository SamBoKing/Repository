package qtec.china.customer.manager;


import qtec.china.customer.model.*;

public class DataManager {
    private static DataManager _instance;
    public static DataManager getInstance() {
        if( _instance == null ) {
            _instance = new DataManager();
        }
        return _instance;
    }

    public static void release() {
        if( _instance != null ) {
            _instance = null;
        }
    }

    public ModelConfig Config = new ModelConfig();
    public ModelUser User = new ModelUser();
    public ModelRider Rider = new ModelRider();
    public ModelSearch Search = new ModelSearch();
    public ModelNotice Notice = new ModelNotice();
    public ModelPrice Price = new ModelPrice();
    public ModelService Service = new ModelService();
    public ModelMileage Mileage = new ModelMileage();
    public ModelHistory History = new ModelHistory();
    public ModelDetail Detail = new ModelDetail();
}
