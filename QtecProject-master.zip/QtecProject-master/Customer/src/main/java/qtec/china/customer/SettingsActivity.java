package qtec.china.customer;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import com.afollestad.materialdialogs.MaterialDialog;
import de.psdev.licensesdialog.NoticesHtmlBuilder;
import de.psdev.licensesdialog.NoticesXmlParser;
import de.psdev.licensesdialog.model.Notices;
import qtec.china.customer.base.BaseActivity;

public class SettingsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initToolbar();
        getFragmentManager().beginTransaction()
                .replace(R.id.setting_content, SettingsFragment.newInstance())
                .commit();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        if( actionBar != null ) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }
    }

    public static class SettingsFragment extends PreferenceFragment {
        public static SettingsFragment newInstance() {
            return new SettingsFragment();
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_settings);

            findPreference(getString(R.string.key_license)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    String licenses = NoticesHtmlBuilder.create(getActivity()).setNotices(getNotices(getActivity(), R.raw.licenses)).build();
                    WebView webView = new WebView(getActivity());
                    webView.loadDataWithBaseURL(null, licenses, "text/html", "utf-8", null);

                    new MaterialDialog.Builder(getActivity())
                            .title(R.string.dialog_license_title)
                            .customView(webView, false)
                            .positiveText(R.string.dialog_license_close)
                            .show();
                    return false;
                }
            });
        }

        private static Notices getNotices(Context context, int rawNoticesResourceId) {
            try {
                Resources e = context.getResources();
                if("raw".equals(e.getResourceTypeName(rawNoticesResourceId))) {
                    Notices notices = NoticesXmlParser.parse(e.openRawResource(rawNoticesResourceId));
                    return notices;
                } else {
                    throw new IllegalStateException("not a raw resource");
                }
            } catch (Exception var4) {
                throw new IllegalStateException(var4);
            }
        }
    }
}
