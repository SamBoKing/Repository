package qtec.china.customer.model;

public class ModelCert {
    public boolean result;
}
