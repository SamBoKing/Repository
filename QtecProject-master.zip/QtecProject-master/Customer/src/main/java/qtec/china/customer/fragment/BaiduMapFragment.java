package qtec.china.customer.fragment;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Response;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.cloud.CloudListener;
import com.baidu.mapapi.cloud.CloudSearchResult;
import com.baidu.mapapi.cloud.DetailSearchResult;
import com.baidu.mapapi.map.*;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.model.LatLngBounds;
import com.baidu.mapapi.search.geocode.GeoCodeOption;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.sug.OnGetSuggestionResultListener;
import com.baidu.mapapi.search.sug.SuggestionSearch;
import com.baidu.mapapi.search.sug.SuggestionSearchOption;
import com.google.gson.Gson;
import com.nispok.snackbar.Snackbar;
import com.nispok.snackbar.SnackbarManager;
import com.orhanobut.logger.Logger;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import qtec.china.customer.R;
import qtec.china.customer.baidumap.RiderClusterRenderer;
import qtec.china.customer.baidumap.library.clustering.Cluster;
import qtec.china.customer.baidumap.library.clustering.ClusterItem;
import qtec.china.customer.baidumap.library.clustering.ClusterManager;
import qtec.china.customer.base.BaseActivity;
import qtec.china.customer.base.BaseBaiduMapFragment;
import qtec.china.customer.common.Common;
import qtec.china.customer.model.ModelRider;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.navercorp.volleyextensions.volleyer.Volleyer.volleyer;
import static qtec.china.customer.helper.UrlHelper.Page;
import static qtec.china.customer.helper.UrlHelper.makeUrl;
import static qtec.china.customer.model.ModelRider.Rider;

public class BaiduMapFragment extends BaseBaiduMapFragment implements
        BaiduMap.OnMyLocationClickListener,
        ClusterManager.OnClusterItemClickListener,
        ClusterManager.OnClusterClickListener,
        CloudListener
{

    final int IMAGE_CHECK_TIME = 1000;
    final int IMAGE_CHECK_COUNT = 3;

    private BaseActivity mActivity;
    private BaiduMap mBaiduMap;
    private LocationClient mClient;
    private MyLocationListenner myListener = new MyLocationListenner();

    private SuggestionSearch mSuggestionSearch;
    private GeoCoder mGeoCoderSearch;

    private ClusterManager<ModelRider.Rider> mClusterManager;
    private List<Target> mTargetList = new ArrayList<>();
    private int mImageCheckCount;

    public static BaiduMapFragment newInstance(BaseActivity activity) {
        MapStatus ms = new MapStatus.Builder().zoom(15).build();
        BaiduMapOptions bo = new BaiduMapOptions().mapStatus(ms)
                .compassEnabled(false).zoomControlsEnabled(false);
        return newInstance(activity, bo);
    }

    public static BaiduMapFragment newInstance(BaseActivity activity, BaiduMapOptions baiduMapOptions) {
        BaiduMapFragment map = new BaiduMapFragment();
        map.setArguments(activity, baiduMapOptions);
        return map;
    }

    public BaiduMapFragment() {
    }

    private void setArguments(BaseActivity activity, BaiduMapOptions baiduMapOptions) {
        mActivity = activity;
        setMapOptions(baiduMapOptions);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        initBaiduMap();
        initSearch();
    }

    private void initBaiduMap() {
        mBaiduMap = getBaiduMap();
        mBaiduMap.setMyLocationEnabled(true);
        mBaiduMap.setOnMyLocationClickListener(this);
        mBaiduMap.getUiSettings().setZoomGesturesEnabled(true);
        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {
                return false;
            }
        });
        mBaiduMap.setOnMapLoadedCallback(new BaiduMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                onMapReady();
            }
        });

        mClusterManager = new ClusterManager<>(mActivity, mBaiduMap);
        mClusterManager.setRenderer(new RiderClusterRenderer(mActivity, mBaiduMap, mClusterManager));
        mClusterManager.setOnClusterItemClickListener(this);
        mClusterManager.setOnClusterClickListener(this);
        mBaiduMap.setOnMapStatusChangeListener(mClusterManager);
        mBaiduMap.setOnMarkerClickListener(mClusterManager);
        // mMap.setOnInfoWindowClickListener(mClusterManager);
    }

    private void initSearch() {
        mSuggestionSearch = SuggestionSearch.newInstance();
        mGeoCoderSearch = GeoCoder.newInstance();
    }

    @Override
    public boolean onMyLocationClick() {
        return false;
    }

    public void onMapReady() {
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true);
        option.setCoorType("bd09ll");
        option.setScanSpan(1000);
        mClient = new LocationClient(mActivity);
        mClient.registerLocationListener(myListener);
        mClient.setLocOption(option);

        BDLocation location = mClient.getLastKnownLocation();
        if( location == null ) {
//            new MaterialDialog.Builder(mActivity)
//                    .content(R.string.failed_location_connect)
//                    .positiveText(R.string.ok)
//                    .show();
        } else {
            mBaiduMap.setMyLocationData(makeLocationData(location));
            moveLocation();
            requestModelRider();
        }
        mClient.start();
    }

    private void moveLocation() {
        MyLocationData location = mBaiduMap.getLocationData();
        if( location == null ) {
            Logger.e("Not Found Location!");
            return;
        }

        LatLng latlng = new LatLng(location.latitude, location.longitude);
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLngZoom(latlng,
                getResources().getInteger(R.integer.map_defuault_zoom)));
    }

    private void requestModelRider() {
        MyLocationData location = mBaiduMap.getLocationData();
        if( location == null ) {
            Logger.e("Not Found Location!");
            return;
        }

        mActivity.displayLoading(true);
        volleyer().get(makeUrl(Page.getRider))
                .addHeader("lat", location.latitude + "")
                .addHeader("lng", location.longitude + "")
                .withErrorListener(mActivity)
                .withListener(new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mActivity.mData.Rider = new Gson().fromJson(response, ModelRider.class);
                        initModelRider();
                    }
                })
                .execute();
    }

    private void initModelRider() {
        loadImage();
        checkImage();
    }

    private void drawModelRider() {
        LatLngBounds.Builder bounds = new LatLngBounds.Builder();
        mClusterManager.clearItems();
        for(Rider r : mActivity.mData.Rider.getList()) {
            mClusterManager.addItem(r);
            bounds.include(r.getPosition());
        }
        mClusterManager.cluster();
        mBaiduMap.animateMapStatus(MapStatusUpdateFactory.newLatLngBounds(bounds.build()));
        mActivity.displayLoading(false);
    }

    private void loadImage() {
        int w = (int)getResources().getDimension(R.dimen.marker_width);
        int h = (int)getResources().getDimension(R.dimen.marker_height);

        for( final Rider r : mActivity.mData.Rider.getList() ) {
            r.setPosition(position());
            Target target = new Target() {
                @Override
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                    r.bitmap = bitmap;
                    mTargetList.remove(this);
                }
                @Override
                public void onBitmapFailed(Drawable errorDrawable) {
                    mTargetList.remove(this);
                }
                @Override
                public void onPrepareLoad(Drawable placeHolderDrawable) { }
            };
            // 강한 참조를 만들기 위한 로직
            mTargetList.add(target);

            Picasso.with(mActivity).load(r.url).resize(w, h).into(target);
        }
    }

    private void checkImage() {
        int count = 0;
        for(Rider r : mActivity.mData.Rider.getList()) {
            if( r.bitmap != null ) count++;
        }

        if( mActivity.mData.Rider.getList().size() == count || mImageCheckCount++ > IMAGE_CHECK_COUNT ) {
            mImageCheckCount = 0;
            drawModelRider();
        } else {
            new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    checkImage();
                    super.handleMessage(msg);
                }
            }.sendEmptyMessageDelayed(0, IMAGE_CHECK_TIME);
        }
    }

    public MyLocationData makeLocationData(BDLocation bd) {
        return new MyLocationData.Builder()
                .accuracy(bd.getRadius())
                .direction(bd.getDirection()).latitude(bd.getLatitude())
                .longitude(bd.getLongitude()).build();
    }

    @Override
    public boolean onClusterItemClick(ClusterItem item) {
        if( item instanceof Rider ) {
            Rider rider = ((Rider)item);

            Drawable img;
            if( rider.bitmap == null ) {
                img = Common.getDrawableWithColorFilter(mActivity, R.drawable.ic_portrait_white_48dp,
                        getResources().getColor(R.color.appThemeColor));
            } else {
                img = new BitmapDrawable(getResources(), rider.bitmap);
            }
            int bound = (int)getResources().getDimension(R.dimen.marker_width);
            img.setBounds(0, 0, bound, bound);

            new MaterialDialog.Builder(mActivity)
                    .title(rider.name)
                    .content(rider.memo)
                    .positiveText(R.string.ok)
                    .icon(img)
                    .show();
        }
        return false;
    }

    // Todo : Test
    @Override
    public boolean onClusterClick(Cluster cluster) {
        final List<Rider> list = new ArrayList<>();
        for(Object item : cluster.getItems() ) {
            if( item instanceof Rider ) {
                list.add((Rider) item);
            }
        }
        CharSequence[] names = new CharSequence[list.size()];
        int index = 0;
        for(Rider r : list) {
            names[index++] = r.name;
        }

        new MaterialDialog.Builder(mActivity)
                .title("Riders : " + cluster.getSize())
                .items(names)
                .itemsCallback(new MaterialDialog.ListCallback() {
                    @Override
                    public void onSelection(MaterialDialog materialDialog, View view, int i, CharSequence charSequence) {
                        Rider rider = list.get(i);
                        SnackbarManager.show(
                                Snackbar.with(mActivity)
                                        .textColorResource(R.color.textColorPrimary)
                                        .colorResource(R.color.appThemeColor)
                                        .text("Rating : " + rider.rating)
                                        .duration(Snackbar.SnackbarDuration.LENGTH_SHORT)
                        );
                    }
                })
                .positiveText(R.string.ok)
                .show();
        return false;
    }

    public void requestSearch(OnGetSuggestionResultListener listener, String keyword) {
        mSuggestionSearch.setOnGetSuggestionResultListener(listener);
        mSuggestionSearch.requestSuggestion((new SuggestionSearchOption()).city("北京").keyword(keyword));
    }

    public void requestSearch(OnGetGeoCoderResultListener listener, String address) {
        mGeoCoderSearch.setOnGetGeoCodeResultListener(listener);
        mGeoCoderSearch.geocode(new GeoCodeOption().city("北京").address(address));
    }

    @Override
    public void onGetSearchResult(CloudSearchResult cloudSearchResult, int i) {

    }

    @Override
    public void onGetDetailSearchResult(DetailSearchResult detailSearchResult, int i) {

    }

    public void updateRider() {
        LatLng latlng = position();
        MyLocationData data = new MyLocationData.Builder()
                .latitude(latlng.latitude)
                .longitude(latlng.longitude).build();

        // Todo : Test
        mBaiduMap.setMyLocationData(data);
        moveLocation();
        requestModelRider();
    }

    public class MyLocationListenner implements BDLocationListener {
        @Override
        public void onReceiveLocation(BDLocation location) {
            if( mBaiduMap.getLocationData() == null && location != null ) {
                if( location.getLatitude() == 4.9E-324 ) {
//                    new MaterialDialog.Builder(mActivity)
//                            .content(R.string.failed_location_connect)
//                            .positiveText(R.string.ok)
//                            .show();

                    location.setLatitude(39.914372);
                    location.setLongitude(116.405347);

                    // Todo : Test
                    mBaiduMap.setMyLocationData(makeLocationData(location));
                    moveLocation();
                    requestModelRider();
                } else {
                    mBaiduMap.setMyLocationData(makeLocationData(location));
                    moveLocation();
                    requestModelRider();
                }
            }
            mClient.stop();
        }
    }

    // Todo : Test
    private Random mRandom = new Random(1984);
//    private static final LatLngBounds BOUNDS_GREATER_SYDNEY = new LatLngBounds(
//            new LatLng(-34.041458, 150.790100), new LatLng(-33.682247, 151.383362));

    private LatLng position() {
        MyLocationData location = mBaiduMap.getLocationData();
        return new LatLng(
                random(location.latitude + 0.03, location.latitude - 0.03),
                random(location.longitude + 0.03, location.longitude - 0.03)
        );
    }

    private double random(double min, double max) {
        return mRandom.nextDouble() * (max - min) + min;
    }
}
