package qtec.china.customer.model;

public class ModelOrder {
    public boolean success;
    public String message;
}
