package qtec.china.customer.model;

import java.util.ArrayList;
import java.util.List;

public class ModelConfig {
    public String call;
    public String email;

    public class Cancel {
        public String id;
        public String text;
    }
    List<Cancel> list_cancel = new ArrayList<>();
    public List<Cancel> getListCancel() {
        return list_cancel;
    }
}
