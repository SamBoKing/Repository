package qtec.china.customer.base;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import qtec.china.customer.manager.DataManager;
import qtec.china.customer.manager.SettingManager;

public class BaseFragment extends Fragment {
    public BaseActivity mActivity;
    public DataManager mData;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mData = DataManager.getInstance();
        mActivity = (BaseActivity)getActivity();
    }
}
