package qtec.china.customer.common;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.widget.TextView;

public class Common {
    public static Drawable getDrawableWithColorFilter(Context context, @DrawableRes int icon, int color) {
        Drawable drawable = context.getResources().getDrawable(icon);
        drawable.setColorFilter(color, PorterDuff.Mode.MULTIPLY);
        return drawable;
    }

    public static int getDimension(Context context, int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    public static void setTextViewColorPartial(TextView view, String subtext, int color) {
        String fulltext = view.getText().toString();
        int i = fulltext.indexOf(subtext);
        if( i == -1 ) return;

        final SpannableStringBuilder sp = new SpannableStringBuilder(fulltext);
        sp.setSpan(new ForegroundColorSpan(color), i, i + subtext.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        view.setText(sp);
    }

    public static int getColorWithAlpha(int color, float alpha) {
        return ( (int) ( alpha * 255.0f ) << 24 ) | ( color & 0x00ffffff);
    }

    public static ColorStateList getStatListColorWithAlpha(int color, float alpha) {
        int not_selected = Common.getColorWithAlpha(color, alpha);
        return new ColorStateList(
                new int[][]{
                        new int[]{ android.R.attr.state_selected },
                        new int[]{ -android.R.attr.state_selected },
                },
                new int[] { color, not_selected }
        );
    }


}
