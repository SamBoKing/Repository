package qtec.china.customer.model;

public class ModelResult {
    public boolean success;
}
