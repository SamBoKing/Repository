package com.quinny898.library.persistentsearch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Point;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView.OnEditorActionListener;
import com.balysv.materialmenu.MaterialMenuDrawable.IconState;
import com.balysv.materialmenu.MaterialMenuView;
import io.codetail.animation.ReverseInterpolator;
import io.codetail.animation.SupportAnimator;
import io.codetail.animation.ViewAnimationUtils;
import qtec.china.library.R;

import java.util.ArrayList;
import java.util.List;

public class SearchBox extends RelativeLayout {

    public static final int VOICE_RECOGNITION_CODE = 1234;

    private InputMethodManager inputMethodManager;
    private Activity mActivity;
    private Context mContext;
    private TextView mSearchText;
    private EditText mSearchEdit;
    private ListView mListView;
    private List<SearchResult> mResults;
    private MaterialMenuView mMenuView;
    private ImageView mIconVoice;
    private ProgressBar mProgress;
    private SearchAdapter mAdapter;

    private SearchListener mSearchListener;
    private MenuListener mMenuListener;
    private ResultListener mResultListener;
    private VoiceListener mVoiceListener;

    private String mSearchHint;
    private int mBackground;
    private boolean isOpen;
    private boolean isVoice;
    private boolean isVoiceSupported;
    private boolean isLoading;

    public interface ResultListener {
        void onResultClick(SearchResult result);
    }

    public interface SearchListener {
        void onSearchOpened();
        void onSearchCleared();
        void onSearchClosed();
        void onSearchTermChanged();
        void onSearch(String result);
    }

    public interface MenuListener {
        void onMenuClick();
    }

    public interface VoiceListener {
        void onClick();
    }

    public SearchBox(Context context) {
        this(context, null);
    }

    public SearchBox(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SearchBox(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        inflate(context, R.layout.search_box, this);

        isOpen = false;
        isVoice = true;
        mSearchHint = "Search";
        mContext = context;
        inputMethodManager = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);

        mMenuView = (MaterialMenuView) findViewById(R.id.material_menu_button);
        mSearchText = (TextView) findViewById(R.id.search_text);
        mSearchEdit = (EditText) findViewById(R.id.search_edit);
        mListView = (ListView) findViewById(R.id.search_list);
        mProgress = (ProgressBar) findViewById(R.id.progress);
        mIconVoice = (ImageView) findViewById(R.id.img_voice);

        mResults = new ArrayList<>();
        mAdapter = new SearchAdapter(context, mResults);
        mListView.setAdapter(mAdapter);
        isVoiceSupported = isIntentAvailable(context, new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH));
        voiceStateChanged();

        mMenuView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (isOpen) {
//                    toggleSearch();
//                } else
                if (mMenuListener != null) {
                    mMenuListener.onMenuClick();
                }
            }
        });



        mSearchText.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSearch();
            }
        });

        mSearchEdit.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    search(getSearchEdit());
                    return true;
                }
                return false;
            }
        });

        mSearchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                voiceStateChanged(!(s.length() > 0));
                if (mSearchListener != null) {
                    mSearchListener.onSearchTermChanged();
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

        });

        mSearchEdit.setOnKeyListener(new OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (isEmptySearch()) {
                        toggleSearch();
                    } else {
                        search(getSearchEdit());
                    }
                    return true;
                }
                return false;
            }
        });

        mIconVoice.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mVoiceListener != null) {
                    mVoiceListener.onClick();
                } else {
                    if (!isVoice) {
                        setSearchEdit("");
                        voiceStateChanged(true);
                    } else {
                        startVoice();
                    }
                }
            }
        });

        mListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                if (mResultListener != null) {
                    SearchResult result = mResults.get(arg2);
                    mResultListener.onResultClick(result);
                }
            }
        });
    }

    private void search(String text) {
        setSearchEdit(text);
        if( !isEmptySearch() ) {
            setSearchText(text);
            if( mSearchListener != null ) {
                mSearchListener.onSearch(text);
            }
        }
        toggleSearch();
    }

    private void openSearch() {
        mMenuView.animateState(IconState.ARROW);
        mSearchText.setVisibility(View.GONE);
        mSearchEdit.setVisibility(View.VISIBLE);
        mSearchEdit.requestFocus();
        mSearchEdit.setSelection(getSearchEdit().length());
        mListView.setVisibility(View.GONE);
        voiceStateChanged(!(getSearchEdit().length() > 0));

        if( isShown() ) {
            inputMethodManager.showSoftInput(mSearchEdit, InputMethodManager.SHOW_IMPLICIT);
        }

        if( mSearchListener != null ) {
            mSearchListener.onSearchOpened();
        }
        isOpen = true;
    }

    private void closeSearch() {
        if( isEmptySearch() ) {
            setSearchText(mSearchHint);
        }

        mMenuView.animateState(IconState.BURGER);
        mSearchText.setVisibility(View.VISIBLE);
        mSearchEdit.setVisibility(View.GONE);
        mListView.setVisibility(View.GONE);
        voiceStateChanged(true);
        inputMethodManager.hideSoftInputFromWindow(getApplicationWindowToken(), 0);

        if( mSearchListener != null ) {
            mSearchListener.onSearchClosed();
        }
        isOpen = false;
    }

    public void revealFromMenuItem(int id, Activity a) {
        if( isShown() ) return;

        setVisibility(View.VISIBLE);
        View menuButton = a.findViewById(id);
        if (menuButton != null) {
            FrameLayout layout = (FrameLayout) a.getWindow().getDecorView().findViewById(android.R.id.content);
            if (layout.findViewWithTag("searchBox") == null) {

                RelativeLayout root = (RelativeLayout) findViewById(R.id.search_root);
                Resources r = getResources();
                float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 96, r.getDisplayMetrics());
                int cx = layout.getLeft() + layout.getRight();
                int cy = layout.getTop();

                int finalRadius = (int) Math.max(layout.getWidth(), px);
                SupportAnimator animator = ViewAnimationUtils.createCircularReveal(root, cx, cy, 0, finalRadius);
                animator.setInterpolator(new AccelerateDecelerateInterpolator());
                animator.setDuration(400);
                animator.addListener(new SupportAnimator.AnimatorListener() {
                    @Override
                    public void onAnimationCancel() {
                    }

                    @Override
                    public void onAnimationEnd() {
                        openSearch();
                    }

                    @Override
                    public void onAnimationRepeat() {
                    }

                    @Override
                    public void onAnimationStart() {
                    }
                });
                animator.start();
            }
        }
    }

    public void hideCircularly(Activity activity) {
        if( !isShown() ) return;

        Display display = activity.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        final FrameLayout layout = (FrameLayout) activity.getWindow().getDecorView()
                .findViewById(android.R.id.content);
        RelativeLayout root = (RelativeLayout) findViewById(R.id.search_root);
        display.getSize(size);
        Resources r = getResources();
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 96,
                r.getDisplayMetrics());
        int cx = layout.getLeft() + layout.getRight();
        int cy = layout.getTop();
        int finalRadius = (int) Math.max(layout.getWidth() * 1.5, px);

        SupportAnimator animator = ViewAnimationUtils.createCircularReveal(root, cx, cy, 0, finalRadius);
        animator.setInterpolator(new ReverseInterpolator());
        animator.setDuration(400);
        animator.start();
        animator.addListener(new SupportAnimator.AnimatorListener() {
            @Override
            public void onAnimationStart() {
            }

            @Override
            public void onAnimationEnd() { setVisibility(View.GONE); closeSearch(); }
            @Override
            public void onAnimationCancel() { }
            @Override
            public void onAnimationRepeat() { }
        });
    }

    public void toggleSearch() {
        if (isOpen) {
            closeSearch();
        } else {
            openSearch();
        }
    }

    public void startVoice() {
        if ( isVoiceEnabled()  ) {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, mContext.getString(R.string.speak_now));
            mActivity.startActivityForResult(intent, VOICE_RECOGNITION_CODE);
        }
    }

    public void enableVoice(Activity context) {
        mActivity = context;
        voiceStateChanged();
    }

    private boolean isVoiceEnabled() {
        return isVoiceSupported && (!isLoading) && (mActivity != null);
    }

    private void voiceStateChanged() {
        mIconVoice.setVisibility((!isVoice || isVoiceEnabled()) ? VISIBLE : INVISIBLE);
    }

    private void voiceStateChanged(boolean isVoice) {
        this.isVoice = isVoice;
        voiceStateChanged();
        mIconVoice.setImageResource(isVoice ? R.drawable.ic_action_mic : R.drawable.ic_clear);
    }

    public void showLoading(boolean show) {
        isLoading = show;
        if (show) {
            mProgress.setVisibility(View.VISIBLE);
            mIconVoice.setVisibility(View.INVISIBLE);
        } else {
            mProgress.setVisibility(View.INVISIBLE);
            mIconVoice.setVisibility(View.VISIBLE);
        }
    }

    public void populateEditText(ArrayList<String> matches) {
        toggleSearch();
        String text = "";
        for (int x = 0; x < matches.size(); x++) {
            text = text + matches.get(x) + " ";
        }
        text = text.trim();
        setSearchEdit(text);
        search(text);
    }

    public void updateResults(List<SearchResult> searchResults) {
        mResults.clear();
        for(SearchResult item : searchResults) {
            mResults.add(item);
        }

        if (mResults.size() == 0) {
            mListView.setVisibility(View.GONE);
        } else {
            mListView.setVisibility(View.VISIBLE);
        }
        mAdapter.refreshSearchData(getSearchEdit());
    }

    public void clearResults() {
        mResults.clear();
        mAdapter.notifyDataSetChanged();
        if( mSearchListener != null ) {
            mSearchListener.onSearchCleared();
        }
    }

    private boolean isEmptySearch() {
        return TextUtils.isEmpty(getSearchEdit());
    }

    public void setMenuVisibility(int visibility) {
        mMenuView.setVisibility(visibility);
    }

    public void setMaxLength(int length) {
        mSearchEdit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(length)});
    }

    public void setSearchHint(String hint) {
        this.mSearchHint = hint;
        setSearchText(hint);
    }

    public String getSearchEdit() {
        return mSearchEdit.getText().toString();
    }

    public void setSearchEdit(String text) {
        mSearchEdit.setText(text);
    }

    private void setSearchText(String text) {
        mSearchText.setText(text);
    }

    public void setItemBackground(int background) {
        if( mAdapter != null ) {
            mAdapter.setBackground(background);
        }
    }

    public void setMenuListener(MenuListener listener) {
        this.mMenuListener = listener;
    }

    public void setSearchListener(SearchListener listener) {
        this.mSearchListener = listener;
    }

    public void setResultListener(ResultListener listener) {
        this.mResultListener = listener;
    }

    private static boolean isIntentAvailable(Context context, Intent intent) {
        PackageManager mgr = context.getPackageManager();
        List<ResolveInfo> list = mgr.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }
}
