package com.quinny898.library.persistentsearch;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import qtec.china.library.R;

import java.util.List;

public class SearchAdapter extends ArrayAdapter<SearchResult> {
    int background;
    String search;
    int forground = Color.parseColor("#FF7011");

    public SearchAdapter(Context context, List<SearchResult> options) {
        super(context, 0, options);
    }

    public void setBackground(int background) {
        this.background = background;
    }

    public void refreshSearchData(String search) {
        this.search = search;
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SearchResult option = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.search_item, parent, false);
            if( background != 0 ) {
                convertView.setBackgroundResource(background);
            }
        }

        View border = convertView.findViewById(R.id.border);
        border.setVisibility((position == 0) ? View.VISIBLE : View.GONE);

        TextView title = (TextView) convertView.findViewById(R.id.title);
        title.setText(option.title);
        if( search != null ) {
            setTextViewColorPartial(title, search, forground);
        }

        ImageView icon = (ImageView) convertView.findViewById(R.id.icon);
        icon.setImageDrawable(option.icon);
        return convertView;
    }

    public void setTextViewColorPartial(TextView view, String subtext, int color) {
        String fulltext = view.getText().toString();
        int i = fulltext.indexOf(subtext);
        if( i == -1 ) return;

        final SpannableStringBuilder sp = new SpannableStringBuilder(fulltext);
        sp.setSpan(new ForegroundColorSpan(color), i, i + subtext.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        view.setText(sp);
    }
}
